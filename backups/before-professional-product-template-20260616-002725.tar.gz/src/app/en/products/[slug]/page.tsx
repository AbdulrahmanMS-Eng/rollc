import { notFound } from "next/navigation";
import { ProductExactPage } from "@/components/rollc/product/ProductExactPage";
import { products } from "@/data/rollc/content";

export function generateStaticParams() {
  return products.map((product) => ({ slug: product.id }));
}

export default async function EnglishProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = products.find((item) => item.id === slug);

  if (!product) notFound();

  return <ProductExactPage locale="en" product={product} />;
}
