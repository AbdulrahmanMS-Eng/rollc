import { TopBar } from "@/components/rollc/layout/TopBar";
import { Header } from "@/components/rollc/layout/Header";
import { Footer } from "@/components/rollc/layout/Footer";
import { RollcProvider } from "@/components/rollc/ui/RollcStore";
import { SearchPanel } from "@/components/rollc/ui/SearchPanel";
import { QuickViewModal } from "@/components/rollc/ui/QuickViewModal";
import { Toast } from "@/components/rollc/ui/Toast";
import { ProductHero } from "@/components/rollc/product/ProductHero";
import type { Locale, Product } from "@/data/rollc/content";

export function ProductExactPage({ locale, product }: { locale: Locale; product: Product }) {
  return (
    <div className="scroll-shell">
      <div className={locale === "en" ? "rollc-page rollc-page-en" : "rollc-page rollc-page-ar"}>
        <RollcProvider locale={locale}>
          <main
            className={locale === "en" ? "rollc-real-page product-page lang-en" : "rollc-real-page product-page"}
            dir={locale === "ar" ? "rtl" : "ltr"}
          >
            <TopBar locale={locale} />
            <Header locale={locale} />

            <ProductHero locale={locale} product={product} />

            <Footer locale={locale} />
            <SearchPanel />
            <QuickViewModal />
            <Toast />
          </main>
        </RollcProvider>
      </div>
    </div>
  );
}
