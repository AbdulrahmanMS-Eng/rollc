"use client";

import { useMemo, useState } from "react";
import { useRollcStore } from "@/components/rollc/ui/RollcStore";
import { currency, type Locale, type Product } from "@/data/rollc/content";

type Option = { ar: string; en: string };

const galleryFallbacks = [
  "https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=1200&q=80",
  "https://images.unsplash.com/photo-1567016432779-094069958ea5?auto=format&fit=crop&w=1200&q=80",
  "https://images.unsplash.com/photo-1540574163026-643ea20ade25?auto=format&fit=crop&w=1200&q=80",
];

const colors = [
  { ar: "رملي فاخر", en: "Sand", value: "#cdb593" },
  { ar: "بني عميق", en: "Deep Brown", value: "#5a4330" },
  { ar: "رمادي حجري", en: "Stone Grey", value: "#8c8a84" },
  { ar: "أخضر زيتي", en: "Olive", value: "#5c6044" },
];

function highRes(src: string) {
  return src.replace("w=700", "w=1200").replace("w=300", "w=1200");
}

function thumb(src: string) {
  return src.replace("w=1200", "w=300").replace("w=700", "w=300");
}

function sizesFor(product: Product): Option[] {
  const category = product.cat.en.toLowerCase();

  if (category.includes("sofa")) {
    return [
      { ar: "2 مقعد", en: "2 Seater" },
      { ar: "3 مقاعد", en: "3 Seater" },
      { ar: "زاوية L", en: "L-Corner" },
    ];
  }

  if (category.includes("chair")) {
    return [
      { ar: "قطعة واحدة", en: "Single" },
      { ar: "زوج", en: "Pair" },
      { ar: "نسخة لاونج", en: "Lounge" },
    ];
  }

  if (category.includes("table")) {
    return [
      { ar: "قهوة", en: "Coffee" },
      { ar: "جانبية", en: "Side" },
      { ar: "طعام", en: "Dining" },
    ];
  }

  if (category.includes("bed")) {
    return [
      { ar: "كوين", en: "Queen" },
      { ar: "كنج", en: "King" },
      { ar: "كنج مع تخزين", en: "King Storage" },
    ];
  }

  return [
    { ar: "قياسي", en: "Standard" },
    { ar: "فاخر", en: "Premium" },
    { ar: "مخصص", en: "Custom" },
  ];
}

function StarIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="m12 2 2.9 6.3 6.9.6-5.2 4.6 1.6 6.7L12 17.3 5.8 20.8l1.6-6.7L2.2 8.9l6.9-.6L12 2Z" />
    </svg>
  );
}

function saveLabel(product: Product, locale: Locale) {
  if (!product.old) return "";

  const oldPrice = Number(product.old.replace(/,/g, ""));
  const price = Number(product.price.replace(/,/g, ""));

  if (!Number.isFinite(oldPrice) || !Number.isFinite(price) || oldPrice <= price) {
    return locale === "ar" ? "عرض محدود" : "Limited offer";
  }

  return locale === "ar" ? `وفّر ${(oldPrice - price).toLocaleString("en-US")} ر.س` : `Save ${(oldPrice - price).toLocaleString("en-US")} SAR`;
}

export function ProductHero({ locale, product }: { locale: Locale; product: Product }) {
  const { addToCart, showToast } = useRollcStore();
  const [activeImage, setActiveImage] = useState(highRes(product.img));
  const [saved, setSaved] = useState(false);
  const [activeColor, setActiveColor] = useState(0);
  const [activeSize, setActiveSize] = useState(1);
  const [qty, setQty] = useState(1);

  const cur = currency(locale);
  const sizes = sizesFor(product);
  const gallery = useMemo(() => [highRes(product.img), ...galleryFallbacks], [product.img]);
  const stars = useMemo(() => Array.from({ length: 5 }, (_, index) => <StarIcon key={index} />), []);
  const discount = saveLabel(product, locale);

  const addProduct = () => {
    addToCart();
    showToast(locale === "ar" ? `تمت إضافة ${product.name.ar} إلى السلة` : `${product.name.en} added to cart`);
  };

  return (
    <>
      <div className="wrap">
        <nav className="crumb" aria-label={locale === "ar" ? "مسار التنقل" : "Breadcrumb"}>
          <a href={locale === "ar" ? "/" : "/en"}>{locale === "ar" ? "الرئيسية" : "Home"}</a>
          <span className="sep">/</span>
          <a href="#">{product.cat[locale]}</a>
          <span className="sep">/</span>
          <span className="now">{product.name[locale]}</span>
        </nav>
      </div>

      <div className="wrap">
        <section className="pdp">
          <div className="gallery">
            <div className="g-main">
              {product.tag[locale] ? <span className="g-badge">{product.tag[locale]}</span> : null}

              <button
                type="button"
                className={`g-save${saved ? " active" : ""}`}
                onClick={() => {
                  const next = !saved;
                  setSaved(next);
                  showToast(next ? (locale === "ar" ? "أُضيفت إلى المفضلة" : "Added to wishlist") : (locale === "ar" ? "أُزيلت من المفضلة" : "Removed from wishlist"));
                }}
                aria-label={locale === "ar" ? "إضافة للمفضلة" : "Add to wishlist"}
              >
                <svg viewBox="0 0 24 24">
                  <path d="M12 20s-7-4.5-7-9.5A3.8 3.8 0 0 1 12 7a3.8 3.8 0 0 1 7 3.5C19 15.5 12 20 12 20Z" />
                </svg>
              </button>

              <button type="button" className="g-zoom" onClick={() => window.open(activeImage, "_blank")}>
                <svg viewBox="0 0 24 24">
                  <circle cx="11" cy="11" r="7" />
                  <path d="m20 20-3-3M11 8v6M8 11h6" />
                </svg>
                <span>{locale === "ar" ? "تكبير" : "Zoom"}</span>
              </button>

              <img src={activeImage} alt={product.name[locale]} />
            </div>

            <div className="thumbs">
              {gallery.map((image, index) => (
                <button
                  type="button"
                  key={`${image}-${index}`}
                  className={`thumb${activeImage === image ? " active" : ""}`}
                  onClick={() => setActiveImage(image)}
                  aria-label={locale === "ar" ? `صورة المنتج ${index + 1}` : `Product image ${index + 1}`}
                >
                  <img src={thumb(image)} alt="" />
                </button>
              ))}
            </div>
          </div>

          <div className="panel">
            <span className="p-eyebrow">{product.cat[locale]} · {product.cat.en}</span>

            <h1 className="p-title">{product.name[locale]}</h1>

            <p className="p-sub">{product.name.en}</p>

            <div className="p-rating">
              <span className="stars">{stars}</span>
              <span>{locale === "ar" ? "4.9 · 128 تقييماً" : "4.9 · 128 reviews"}</span>
            </div>

            <div className="p-price">
              <span className="now">{product.price}<span className="cur">{cur}</span></span>
              {product.old ? <span className="old">{product.old} {cur}</span> : null}
              {discount ? <span className="save">{discount}</span> : null}
            </div>

            <p className="p-desc">{product.desc[locale]}</p>

            <div className="opt">
              <div className="opt-head">
                <span className="opt-label">{locale === "ar" ? "اللون" : "Colour"}</span>
                <span className="opt-value">{colors[activeColor][locale]}</span>
              </div>

              <div className="colors">
                {colors.map((color, index) => (
                  <button
                    type="button"
                    key={color.value}
                    className={`color${activeColor === index ? " active" : ""}`}
                    onClick={() => setActiveColor(index)}
                  >
                    <span className="dot" style={{ background: color.value }} />
                    <span className="nm">{color[locale]}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="opt">
              <div className="opt-head">
                <span className="opt-label">{locale === "ar" ? "المقاس / التكوين" : "Size / Configuration"}</span>
                <span className="opt-value">{sizes[activeSize]?.[locale] ?? sizes[0][locale]}</span>
              </div>

              <div className="sizes">
                {sizes.map((size, index) => (
                  <button
                    type="button"
                    key={size.en}
                    className={`size${activeSize === index ? " active" : ""}`}
                    onClick={() => setActiveSize(index)}
                  >
                    {size[locale]}
                  </button>
                ))}
              </div>
            </div>

            <div className="buy-row">
              <div className="qty">
                <button type="button" onClick={() => setQty((value) => Math.max(1, value - 1))} aria-label={locale === "ar" ? "إنقاص" : "Decrease"}>−</button>
                <span className="q-val">{qty}</span>
                <button type="button" onClick={() => setQty((value) => Math.min(99, value + 1))} aria-label={locale === "ar" ? "زيادة" : "Increase"}>+</button>
              </div>

              <button type="button" className="add-cart" onClick={addProduct}>
                <svg viewBox="0 0 24 24">
                  <path d="M6 7h12l-1 13H7L6 7Z" />
                  <path d="M9 7a3 3 0 0 1 6 0" />
                </svg>
                <span>{locale === "ar" ? "أضف إلى السلة" : "Add to cart"}</span>
              </button>
            </div>

            <button
              type="button"
              className="consult"
              onClick={() => showToast(locale === "ar" ? "سيتواصل معك مستشار التصميم قريباً ✦" : "Our design consultant will contact you soon ✦")}
            >
              <svg viewBox="0 0 24 24">
                <path d="M21 15a4 4 0 0 1-4 4H8l-5 3V6a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z" />
              </svg>
              <span>{locale === "ar" ? "احجز استشارة تصميم" : "Book a design consultation"}</span>
            </button>

            <div className="meta-line stock">
              <span className="dot"></span>
              <span><b>{locale === "ar" ? "متوفر للطلب" : "Available to order"}</b>{locale === "ar" ? " — يصل خلال 5 إلى 10 أيام" : " — arrives in 5 to 10 days"}</span>
            </div>

            <div className="meta-line">
              <span className="ic">
                <svg viewBox="0 0 24 24">
                  <path d="M3 13h12V6H3v7Z" />
                  <path d="M15 9h4l2 3v1h-6" />
                  <circle cx="6.5" cy="16.5" r="1.6" />
                  <circle cx="17.5" cy="16.5" r="1.6" />
                </svg>
              </span>
              <span>{locale === "ar" ? "توصيل وتركيب احترافي داخل المملكة" : "Professional delivery & installation in the Kingdom"}</span>
            </div>

            <div className="trust">
              <span className="tlabel">{locale === "ar" ? "دفع آمن موثوق" : "Secure checkout"}</span>
              <div className="pay-methods">
                <span className="b">Mada</span>
                <span className="b">Visa</span>
                <span className="b">Apple Pay</span>
                <span className="b">Tamara</span>
              </div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}
