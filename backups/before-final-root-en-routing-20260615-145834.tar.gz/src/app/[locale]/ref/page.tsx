import { notFound } from "next/navigation";

export default async function RollcReferencePage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;

  if (locale !== "ar" && locale !== "en") notFound();

  return (
    <main className="rollc-pixel-shell">
      <iframe
        className="rollc-pixel-frame"
        title="Rollc reference"
        src={locale === "ar" ? "/rollc-pixel-ar.html?v=ref" : "/rollc-pixel-ar.html?v=ref"}
        loading="eager"
      />
    </main>
  );
}
