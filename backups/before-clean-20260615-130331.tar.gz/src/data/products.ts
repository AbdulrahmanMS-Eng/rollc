import type { Localized } from "@/lib/i18n";

export interface Product {
  cat: Localized;
  name: Localized;
  desc: Localized;
  price: string;
  old: string;
  tag: Localized;
  img: string;
}

export const products: Product[] = [
  {
    cat: { ar: "أرائك", en: "Sofas" },
    name: { ar: "أريكة ميلانو", en: "Milano Sofa" },
    desc: { ar: "أريكة ثلاثية بقماش مخملي ناعم.", en: "Three-seater in soft velvet upholstery." },
    price: "4,250", old: "4,990",
    tag: { ar: "الأكثر مبيعاً", en: "Best seller" },
    img: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=700&q=80",
  },
  {
    cat: { ar: "كراسي", en: "Chairs" },
    name: { ar: "كرسي أوسلو", en: "Oslo Chair" },
    desc: { ar: "كرسي مريح بهيكل خشب الجوز.", en: "Lounge chair on a walnut frame." },
    price: "1,750", old: "",
    tag: { ar: "جديد", en: "New" },
    img: "https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&w=700&q=80",
  },
  {
    cat: { ar: "طاولات", en: "Tables" },
    name: { ar: "طاولة نورديك", en: "Nordic Table" },
    desc: { ar: "طاولة قهوة بسطح رخامي أنيق.", en: "Coffee table with a marble top." },
    price: "2,900", old: "",
    tag: { ar: "", en: "" },
    img: "https://images.unsplash.com/photo-1532372320572-cda25653a26d?auto=format&fit=crop&w=700&q=80",
  },
  {
    cat: { ar: "أسرّة", en: "Beds" },
    name: { ar: "سرير سرين", en: "Serene Bed" },
    desc: { ar: "سرير كنج منجّد بلون رملي دافئ.", en: "Upholstered king bed in warm sand." },
    price: "5,600", old: "6,400",
    tag: { ar: "عرض", en: "Offer" },
    img: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=700&q=80",
  },
  {
    cat: { ar: "أرائك", en: "Sofas" },
    name: { ar: "أريكة روما", en: "Roma Sofa" },
    desc: { ar: "أريكة زاوية جلدية بلمسة فاخرة.", en: "Leather corner sofa, luxe finish." },
    price: "6,800", old: "",
    tag: { ar: "فاخر", en: "Premium" },
    img: "https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=700&q=80",
  },
  {
    cat: { ar: "كراسي", en: "Chairs" },
    name: { ar: "كرسي كوبنهاغن", en: "Copenhagen Chair" },
    desc: { ar: "كرسي مكتب بتصميم اسكندنافي.", en: "Scandinavian-style accent chair." },
    price: "1,450", old: "",
    tag: { ar: "", en: "" },
    img: "https://images.unsplash.com/photo-1592078615290-033ee584e267?auto=format&fit=crop&w=700&q=80",
  },
  {
    cat: { ar: "طاولات", en: "Tables" },
    name: { ar: "طاولة طعام أرابيسك", en: "Arabesque Dining" },
    desc: { ar: "طاولة طعام لثمانية أشخاص.", en: "Dining table seating eight." },
    price: "7,200", old: "",
    tag: { ar: "جديد", en: "New" },
    img: "https://images.unsplash.com/photo-1617806118233-18e1de247200?auto=format&fit=crop&w=700&q=80",
  },
  {
    cat: { ar: "ديكور", en: "Decor" },
    name: { ar: "مصباح أمبر", en: "Amber Lamp" },
    desc: { ar: "مصباح أرضي بإضاءة دافئة.", en: "Floor lamp with warm glow." },
    price: "890", old: "1,150",
    tag: { ar: "عرض", en: "Offer" },
    img: "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&w=700&q=80",
  },
];
