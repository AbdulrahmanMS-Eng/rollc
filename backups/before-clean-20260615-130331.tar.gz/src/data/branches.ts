import type { Localized } from "@/lib/i18n";

export interface Branch {
  city: Localized;
  addr: Localized;
  hours: string;
}

export const branches: Branch[] = [
  {
    city: { ar: "الرياض", en: "Riyadh" },
    addr: { ar: "طريق الملك فهد، حي العليا", en: "King Fahd Rd, Al Olaya District" },
    hours: "10:00 — 23:00",
  },
  {
    city: { ar: "جدة", en: "Jeddah" },
    addr: { ar: "طريق الأمير سلطان، الزهراء", en: "Prince Sultan Rd, Al Zahraa" },
    hours: "10:00 — 23:00",
  },
  {
    city: { ar: "الدمام", en: "Dammam" },
    addr: { ar: "طريق الملك سعود، الشاطئ", en: "King Saud Rd, Al Shati" },
    hours: "10:00 — 23:00",
  },
  {
    city: { ar: "الخبر", en: "Khobar" },
    addr: { ar: "كورنيش الخبر، العقربية", en: "Khobar Corniche, Al Aqrabiyah" },
    hours: "10:00 — 23:00",
  },
];
