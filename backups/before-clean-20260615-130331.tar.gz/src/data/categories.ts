import type { Localized } from "@/lib/i18n";

export interface Category {
  num: string;
  title: Localized;
  sub: Localized;
  img: string;
  alt: string;
}

export const categories: Category[] = [
  {
    num: "/ 01",
    title: { ar: "غرف المعيشة", en: "Living Rooms" },
    sub: { ar: "مساحاتٌ للقاء والدفء", en: "Spaces for gathering and warmth" },
    img: "https://images.unsplash.com/photo-1567016432779-094069958ea5?auto=format&fit=crop&w=1200&q=80",
    alt: "غرف المعيشة",
  },
  {
    num: "/ 02",
    title: { ar: "غرف النوم", en: "Bedrooms" },
    sub: { ar: "هدوءٌ يبدأ من التفاصيل", en: "Calm that begins in the details" },
    img: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=80",
    alt: "غرف النوم",
  },
  {
    num: "/ 03",
    title: { ar: "غرف الطعام", en: "Dining" },
    sub: { ar: "موائد تجمع الأحبة", en: "Tables that bring people together" },
    img: "https://images.unsplash.com/photo-1617806118233-18e1de247200?auto=format&fit=crop&w=900&q=80",
    alt: "غرف الطعام",
  },
  {
    num: "/ 04",
    title: { ar: "أثاث المكاتب", en: "Office" },
    sub: { ar: "إنتاجيةٌ بأناقة", en: "Productivity, elegantly" },
    img: "https://images.unsplash.com/photo-1524758631624-e2822e304c36?auto=format&fit=crop&w=900&q=80",
    alt: "أثاث المكاتب",
  },
  {
    num: "/ 05",
    title: { ar: "الديكور والإكسسوارات", en: "Decor & Accents" },
    sub: { ar: "لمساتٌ تُكمل المشهد", en: "Finishing touches that complete the scene" },
    img: "https://images.unsplash.com/photo-1513161455079-7dc1de15ef3e?auto=format&fit=crop&w=900&q=80",
    alt: "الديكور والإكسسوارات",
  },
];
