"use client";

import { useState } from "react";
import Header from "./layout/Header";
import Footer from "./layout/Footer";
import Hero from "./sections/Hero";
import Categories from "./sections/Categories";
import Signature from "./sections/Signature";
import Products from "./sections/Products";
import DayNightShowroom from "./sections/DayNightShowroom";
import Collections from "./sections/Collections";
import Branches from "./sections/Branches";
import SearchPanel from "./ui/SearchPanel";
import QuickViewModal from "./ui/QuickViewModal";
import Toast from "./ui/Toast";

export default function ClientShell() {
  const [searchOpen, setSearchOpen] = useState(false);
  const [modalIdx, setModalIdx] = useState<number | null>(null);

  return (
    <>
      <Header onSearchOpen={() => setSearchOpen(true)} />
      <main>
        <Hero />
        <Categories />
        <Signature />
        <Products onQuickView={setModalIdx} />
        <DayNightShowroom />
        <Collections />
        <Branches />
      </main>
      <Footer />
      <SearchPanel open={searchOpen} onClose={() => setSearchOpen(false)} />
      <QuickViewModal productIdx={modalIdx} onClose={() => setModalIdx(null)} />
      <Toast />
    </>
  );
}
