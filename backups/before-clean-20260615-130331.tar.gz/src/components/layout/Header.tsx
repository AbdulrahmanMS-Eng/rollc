"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { useLanguage } from "@/providers/LanguageProvider";
import { useCart } from "@/providers/CartProvider";
import MobileNav from "./MobileNav";

const navLinks = [
  { href: "#", ar: "الرئيسية", en: "Home" },
  { href: "#categories", ar: "غرف المعيشة", en: "Living" },
  { href: "#categories", ar: "غرف النوم", en: "Bedroom" },
  { href: "#products", ar: "طاولات", en: "Tables" },
  { href: "#collections", ar: "ديكور", en: "Decor" },
  { href: "#products", ar: "العروض", en: "Offers" },
  { href: "#branches", ar: "الفروع", en: "Showrooms" },
];

interface Props {
  onSearchOpen: () => void;
}

export default function Header({ onSearchOpen }: Props) {
  const { lang, setLang } = useLanguage();
  const { count, showToast } = useCart();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const prevCount = useRef(count);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleCartClick = () => {
    showToast(
      count
        ? lang === "ar"
          ? `لديك ${count} منتج في السلة`
          : `${count} item(s) in your cart`
        : lang === "ar"
        ? "سلتك فارغة"
        : "Your cart is empty"
    );
  };

  return (
    <>
      <div className="topbar">
        <span>
          {lang === "ar"
            ? <>توصيل وتركيب احترافي لكل أنحاء المملكة — <b>استشارة تصميم مجانية</b></>
            : <>Professional delivery &amp; installation across the Kingdom — <b>Free design consultation</b></>}
        </span>
      </div>

      <header className={`header${scrolled ? " scrolled" : ""}`}>
        <div className="wrap">
          <nav className="nav" aria-label="التنقل الرئيسي">
            <a href="#" className="brand" aria-label="Rollc رولك">
              <span className="mark">Roll<b>c</b></span>
              <span className="ar">رولـك</span>
            </a>

            <ul className="menu">
              {navLinks.map((l) => (
                <li key={l.ar}>
                  <a href={l.href}>{lang === "ar" ? l.ar : l.en}</a>
                </li>
              ))}
            </ul>

            <div className="actions">
              <button className="icon-btn" onClick={onSearchOpen} aria-label="بحث">
                <svg viewBox="0 0 24 24" aria-hidden="true">
                  <circle cx="11" cy="11" r="7" />
                  <path d="m20 20-3.5-3.5" />
                </svg>
              </button>

              <button className="icon-btn" onClick={handleCartClick} aria-label="السلة">
                <svg viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M6 7h12l-1 13H7L6 7Z" />
                  <path d="M9 7a3 3 0 0 1 6 0" />
                </svg>
                <motion.span
                  key={count}
                  className="cart-count"
                  initial={{ scale: 1 }}
                  animate={{ scale: [1, 1.5, 1] }}
                  transition={{ duration: 0.4 }}
                >
                  {count}
                </motion.span>
              </button>

              <div className="lang-switch" role="group" aria-label="Language">
                <button
                  className={lang === "ar" ? "active" : ""}
                  onClick={() => setLang("ar")}
                >
                  ع
                </button>
                <button
                  className={lang === "en" ? "active" : ""}
                  onClick={() => setLang("en")}
                >
                  EN
                </button>
              </div>

              <a href="#products" className="cta-shop">
                {lang === "ar" ? "تسوّق الآن" : "Shop now"}
              </a>

              <button
                className={`burger${mobileOpen ? " open" : ""}`}
                onClick={() => setMobileOpen((v) => !v)}
                aria-label="القائمة"
                aria-expanded={mobileOpen}
              >
                <span />
                <span />
                <span />
              </button>
            </div>
          </nav>
        </div>
      </header>

      <MobileNav open={mobileOpen} onClose={() => setMobileOpen(false)} />
    </>
  );
}
