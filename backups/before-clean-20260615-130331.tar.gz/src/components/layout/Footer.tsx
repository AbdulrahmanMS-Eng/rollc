"use client";

import { useState } from "react";
import { useLanguage } from "@/providers/LanguageProvider";

const shopLinks = [
  { ar: "غرف المعيشة", en: "Living Rooms" },
  { ar: "غرف النوم", en: "Bedrooms" },
  { ar: "طاولات الطعام", en: "Dining Tables" },
  { ar: "الديكور", en: "Decor" },
  { ar: "العروض", en: "Offers" },
];

const companyLinks = [
  { ar: "من نحن", en: "About us" },
  { ar: "الفروع", en: "Showrooms" },
  { ar: "التوصيل والتركيب", en: "Delivery & Install" },
  { ar: "سياسة الإرجاع", en: "Returns" },
  { ar: "تواصل معنا", en: "Contact" },
];

export default function Footer() {
  const { lang } = useLanguage();
  const [email, setEmail] = useState("");
  const [okMsg, setOkMsg] = useState("");

  const handleSubscribe = () => {
    if (/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      setOkMsg(
        lang === "ar"
          ? "تم الاشتراك بنجاح ✦ مرحباً بك في رولك"
          : "Subscribed ✦ Welcome to Rollc"
      );
      setEmail("");
    } else {
      setOkMsg(
        lang === "ar"
          ? "فضلاً أدخل بريداً إلكترونياً صحيحاً"
          : "Please enter a valid email"
      );
    }
  };

  return (
    <footer className="footer">
      <div className="wrap">
        <div className="foot-top">
          <div className="foot-brand foot-col">
            <span className="mark">Roll<b>c</b></span>
            <div className="ar">رولـك</div>
            <p className="foot-statement">
              {lang === "ar"
                ? "رولك — حيث يلتقي التصميم بالدفء. نصنع مساحاتٍ تُحاكي ذوقك وتروي حكايتك."
                : "Rollc — where design meets warmth. We craft spaces that echo your taste and tell your story."}
            </p>
            <div className="socials">
              {["IG", "X", "PIN", "TT"].map((s) => (
                <a key={s} href="#" aria-label={s}>{s}</a>
              ))}
            </div>
          </div>

          <div className="foot-col">
            <h4>{lang === "ar" ? "تسوّق" : "Shop"}</h4>
            {shopLinks.map((l) => (
              <a key={l.ar} href="#">{lang === "ar" ? l.ar : l.en}</a>
            ))}
          </div>

          <div className="foot-col">
            <h4>{lang === "ar" ? "الشركة" : "Company"}</h4>
            {companyLinks.map((l) => (
              <a key={l.ar} href="#">{lang === "ar" ? l.ar : l.en}</a>
            ))}
          </div>

          <div className="foot-col news">
            <h4>{lang === "ar" ? "انضم إلى رولك" : "Join Rollc"}</h4>
            <p>
              {lang === "ar"
                ? "اشترك لتصلك المجموعات الجديدة والعروض الحصرية قبل الجميع."
                : "Subscribe for new collections and exclusive offers before anyone else."}
            </p>
            <div className="news-form">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={lang === "ar" ? "بريدك الإلكتروني" : "Your email"}
                aria-label={lang === "ar" ? "البريد الإلكتروني" : "Email address"}
                onKeyDown={(e) => e.key === "Enter" && handleSubscribe()}
              />
              <button onClick={handleSubscribe}>
                {lang === "ar" ? "اشترك" : "Subscribe"}
              </button>
            </div>
            <div className="news-ok" aria-live="polite">{okMsg}</div>
          </div>
        </div>

        <div className="foot-bottom">
          <span>
            © 2026 Rollc رولك.{" "}
            {lang === "ar" ? "جميع الحقوق محفوظة." : "All rights reserved."}
          </span>
          <span className="pay">
            {lang === "ar" ? "طرق الدفع:" : "We accept:"}{" "}
            Mada · Visa · Apple Pay · Tamara
          </span>
        </div>
      </div>
    </footer>
  );
}
