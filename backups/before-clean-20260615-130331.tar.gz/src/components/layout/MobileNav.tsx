"use client";

import { useLanguage } from "@/providers/LanguageProvider";

interface Props {
  open: boolean;
  onClose: () => void;
}

const links = [
  { href: "#", ar: "الرئيسية", en: "Home" },
  { href: "#categories", ar: "غرف المعيشة", en: "Living" },
  { href: "#categories", ar: "غرف النوم", en: "Bedroom" },
  { href: "#products", ar: "طاولات", en: "Tables" },
  { href: "#collections", ar: "ديكور", en: "Decor" },
  { href: "#products", ar: "العروض", en: "Offers" },
  { href: "#branches", ar: "الفروع", en: "Showrooms" },
];

export default function MobileNav({ open, onClose }: Props) {
  const { lang } = useLanguage();

  return (
    <div className={`mobile-nav${open ? " open" : ""}`} aria-hidden={!open}>
      <button className="mn-close" onClick={onClose} aria-label="إغلاق">✕</button>
      {links.map((l) => (
        <a key={l.ar} href={l.href} onClick={onClose}>
          {lang === "ar" ? l.ar : l.en}
        </a>
      ))}
      <a href="#products" className="btn btn--solid mn-cta" onClick={onClose}>
        {lang === "ar" ? "تسوّق الآن" : "Shop now"}
      </a>
    </div>
  );
}
