"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { useLanguage } from "@/providers/LanguageProvider";
import { reveal, viewport } from "@/lib/motion";

const pillars = [
  {
    ar: "خاماتٌ أصيلة",
    en: "Authentic materials",
    descAr: "خشبٌ طبيعي وجلودٌ وأقمشة منتقاة بعناية.",
    descEn: "Solid wood, fine leathers, and carefully chosen fabrics.",
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M12 3 4 7v6c0 4 3.5 7 8 8 4.5-1 8-4 8-8V7l-8-4Z" />
      </svg>
    ),
  },
  {
    ar: "راحةٌ مدروسة",
    en: "Considered comfort",
    descAr: "هندسةٌ مريحة تدعم جسمك في كل جلسة.",
    descEn: "Ergonomic design that supports you in every seat.",
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M3 18v-6a5 5 0 0 1 5-5h8a5 5 0 0 1 5 5v6" />
        <path d="M3 18h18M6 18v2M18 18v2M5 12h14" />
      </svg>
    ),
  },
  {
    ar: "تصميمٌ معاصر",
    en: "Modern design",
    descAr: "خطوطٌ نظيفة بروحٍ خليجية أنيقة.",
    descEn: "Clean lines with a refined Gulf spirit.",
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="m12 2 2.4 4.9 5.4.8-3.9 3.8.9 5.4-4.8-2.5-4.8 2.5.9-5.4L4.2 7.7l5.4-.8L12 2Z" />
      </svg>
    ),
  },
  {
    ar: "توصيل وتركيب",
    en: "Delivery & install",
    descAr: "فريقٌ متخصص يوصّل ويركّب في منزلك.",
    descEn: "A dedicated team delivers and installs at home.",
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M3 13h12V6H3v7Z" />
        <path d="M15 9h4l2 3v1h-6" />
        <circle cx="6.5" cy="16.5" r="1.6" />
        <circle cx="17.5" cy="16.5" r="1.6" />
      </svg>
    ),
  },
];

export default function Signature() {
  const { lang } = useLanguage();

  return (
    <section className="section signature" style={{ background: "var(--ivory)" }}>
      <div className="wrap">
        <div className="sig-grid">
          <motion.div
            className="sig-visual"
            variants={reveal}
            initial="hidden"
            whileInView="visible"
            viewport={viewport}
          >
            <div className="main">
              <Image
                src="https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1000&q=80"
                alt={lang === "ar" ? "حرفية رولك" : "Rollc craftsmanship"}
                width={800}
                height={1000}
                className="object-cover"
                style={{ width: "100%", height: "100%" }}
              />
            </div>
            <div className="badge">
              <div className="num">12</div>
              <div className="lbl">
                {lang === "ar"
                  ? "عاماً من الحرفية في صناعة الأثاث الفاخر"
                  : "Years of craftsmanship in fine furniture"}
              </div>
            </div>
          </motion.div>

          <motion.div
            className="sig-text"
            variants={reveal}
            initial="hidden"
            whileInView="visible"
            viewport={viewport}
          >
            <span className="eyebrow">
              {lang === "ar" ? "لماذا رولك" : "Why Rollc"}
            </span>
            <h2 className="h-display">
              {lang === "ar"
                ? "فخامةٌ تُلمَس في كل تفصيلة"
                : "Luxury you can feel in every detail"}
            </h2>
            <p className="lead">
              {lang === "ar"
                ? "نختار الخامات الطبيعية ونعمل عليها بأيدي حِرفيين، لنقدّم قطعاً تجمع بين الجمال البصري والراحة الحقيقية، وتدوم معك لسنوات."
                : "We select natural materials and shape them by the hands of skilled artisans, delivering pieces that pair visual beauty with genuine comfort, built to last for years."}
            </p>

            <div className="pillars">
              {pillars.map((p) => (
                <div key={p.ar} className="pillar">
                  <span className="pi">{p.icon}</span>
                  <h3>{lang === "ar" ? p.ar : p.en}</h3>
                  <p>{lang === "ar" ? p.descAr : p.descEn}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
