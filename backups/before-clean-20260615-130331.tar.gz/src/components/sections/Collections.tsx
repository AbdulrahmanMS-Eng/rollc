"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { useLanguage } from "@/providers/LanguageProvider";
import { reveal, viewport } from "@/lib/motion";

const collections = [
  {
    idx: "I",
    title: { ar: "مجموعة الهدوء", en: "The Serenity" },
    sub: { ar: "بألوانٍ ترابية ومساحاتٍ تتنفّس بسكينة.", en: "Earthy tones and spaces that breathe with calm." },
    img: "https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=1000&q=80",
    alt: "مجموعة الهدوء",
  },
  {
    idx: "II",
    title: { ar: "مجموعة الفخامة", en: "The Opulence" },
    sub: { ar: "خاماتٌ راقية وتفاصيل ذهبية تعكس الذوق الرفيع.", en: "Refined materials and golden details for a discerning taste." },
    img: "https://images.unsplash.com/photo-1631679706909-1844bbd07221?auto=format&fit=crop&w=1000&q=80",
    alt: "مجموعة الفخامة",
  },
  {
    idx: "III",
    title: { ar: "المساحات العصرية", en: "Modern Spaces" },
    sub: { ar: "خطوطٌ نظيفة لروحٍ معاصرة وحياةٍ مرنة.", en: "Clean lines for a contemporary, flexible way of living." },
    img: "https://images.unsplash.com/photo-1618219740975-d40978bb7378?auto=format&fit=crop&w=1000&q=80",
    alt: "المساحات العصرية",
  },
];

export default function Collections() {
  const { lang } = useLanguage();

  return (
    <section className="section collections" id="collections" style={{ background: "var(--ivory)" }}>
      <div className="wrap">
        <motion.div
          className="sec-head"
          variants={reveal}
          initial="hidden"
          whileInView="visible"
          viewport={viewport}
        >
          <div>
            <span className="eyebrow">
              {lang === "ar" ? "مجموعاتنا المميزة" : "Signature collections"}
            </span>
            <h2 className="h-display">
              {lang === "ar" ? "ثلاث حكاياتٍ من التصميم" : "Three stories in design"}
            </h2>
          </div>
        </motion.div>

        <motion.div
          className="coll-grid"
          variants={reveal}
          initial="hidden"
          whileInView="visible"
          viewport={viewport}
        >
          {collections.map((c) => (
            <article key={c.idx} className="coll">
              <Image
                src={c.img}
                alt={c.alt}
                fill
                className="object-cover"
                style={{ position: "absolute", inset: 0, zIndex: -2 }}
                sizes="(max-width: 620px) 100vw, (max-width: 1080px) 50vw, 33vw"
              />
              <div className="coll-body">
                <span className="coll-idx">{c.idx}</span>
                <h3 className="coll-title">
                  {lang === "ar" ? c.title.ar : c.title.en}
                </h3>
                <p className="coll-sub">
                  {lang === "ar" ? c.sub.ar : c.sub.en}
                </p>
                <a href="#" className="coll-link">
                  <span>{lang === "ar" ? "استكشف" : "Explore"}</span> →
                </a>
              </div>
            </article>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
