"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { useLanguage } from "@/providers/LanguageProvider";
import { categories } from "@/data/categories";
import { reveal, viewport } from "@/lib/motion";

export default function Categories() {
  const { lang } = useLanguage();

  return (
    <section className="section cats" id="categories" style={{ background: "var(--paper)" }}>
      <div className="wrap">
        <motion.div
          className="sec-head"
          variants={reveal}
          initial="hidden"
          whileInView="visible"
          viewport={viewport}
        >
          <div>
            <span className="eyebrow">
              {lang === "ar" ? "تسوّق حسب المساحة" : "Shop by space"}
            </span>
            <h2 className="h-display">
              {lang === "ar" ? "غرفٌ مصممة لتُحاكي أسلوبك" : "Rooms designed to echo your style"}
            </h2>
          </div>
          <a href="#products" className="sec-link">
            <span>{lang === "ar" ? "كل الفئات" : "All categories"}</span>
            <span className="arrow">→</span>
          </a>
        </motion.div>

        <motion.div
          className="cat-grid"
          variants={reveal}
          initial="hidden"
          whileInView="visible"
          viewport={viewport}
        >
          {categories.map((cat, i) => (
            <article key={cat.num} className="cat">
              <Image
                src={cat.img}
                alt={cat.alt}
                fill
                className="object-cover"
                style={{ position: "absolute", inset: 0, zIndex: -2 }}
                sizes="(max-width: 620px) 100vw, (max-width: 1080px) 50vw, 25vw"
              />
              <div className="cat-body">
                <span className="cat-num">{cat.num}</span>
                <h3 className="cat-title">{lang === "ar" ? cat.title.ar : cat.title.en}</h3>
                <p className="cat-sub">{lang === "ar" ? cat.sub.ar : cat.sub.en}</p>
                <span className="cat-go">
                  {lang === "ar" ? "اكتشف" : "Discover"} ←
                </span>
              </div>
            </article>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
