"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { useLanguage } from "@/providers/LanguageProvider";
import { EASE } from "@/lib/motion";

export default function Hero() {
  const { lang, dir } = useLanguage();

  return (
    <section className="hero">
      {/* Background */}
      <div className="hero-bg">
        <motion.div
          className="absolute inset-0 w-full h-full"
          initial={{ scale: 1.12 }}
          animate={{ scale: 1 }}
          transition={{ duration: 12, ease: EASE }}
        >
          <Image
            src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=2000&q=80"
            alt={lang === "ar" ? "غرفة معيشة فاخرة من رولك" : "Rollc luxury living room"}
            fill
            priority
            className="object-cover"
          />
        </motion.div>
        <div className="hero-overlay" />
      </div>

      {/* Content */}
      <div className="wrap">
        <div className="hero-inner">
          <motion.span
            className="eyebrow"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.7, ease: EASE }}
          >
            {lang === "ar" ? "رولك — أثاث فاخر" : "Rollc — Fine Furniture"}
          </motion.span>

          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8, ease: EASE }}
          >
            {lang === "ar" ? (
              <>أثاث يصنع<br /><em>حضور المكان</em></>
            ) : (
              <>Furniture that<br /><em>commands the room</em></>
            )}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.7, ease: EASE }}
          >
            {lang === "ar"
              ? "قطعٌ مختارة بعناية، وغرفٌ منسّقة بلمسة فنية، مع خدمة توصيل وتركيب احترافية تصل إلى باب منزلك في جميع أنحاء المملكة."
              : "Carefully curated pieces and artfully styled rooms, with professional delivery and installation brought right to your door across the Kingdom."}
          </motion.p>

          <motion.div
            className="hero-cta"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 0.6, ease: EASE }}
          >
            <a href="#categories" className="btn btn--solid">
              <span>{lang === "ar" ? "استكشف المجموعات" : "Explore collections"}</span>
              <span className="arrow">→</span>
            </a>
            <a href="#showroom" className="btn btn--ghost">
              <span>{lang === "ar" ? "صمّم غرفتك" : "Design your room"}</span>
            </a>
          </motion.div>
        </div>
      </div>

      {/* Floating product card */}
      <motion.aside
        className="hero-card"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1, duration: 0.8, ease: EASE }}
      >
        <Image
          src="https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=400&q=80"
          alt={lang === "ar" ? "أريكة ميلانو" : "Milano Sofa"}
          width={70}
          height={70}
          className="object-cover rounded"
          style={{ flexShrink: 0, borderRadius: 4 }}
        />
        <div>
          <span className="hc-tag">Best seller</span>
          <p className="hc-name">{lang === "ar" ? "أريكة ميلانو" : "Milano Sofa"}</p>
          <p className="hc-price">4,250 <span style={{ fontSize: "0.74rem" }}>{lang === "ar" ? "ر.س" : "SAR"}</span></p>
        </div>
      </motion.aside>

      {/* Scroll indicator */}
      <div className="hero-scroll">
        <span>{lang === "ar" ? "مرّر" : "Scroll"}</span>
        <motion.span
          style={{ width: 1, height: 42, background: "linear-gradient(rgba(246,241,232,.7),transparent)", display: "block" }}
          animate={{ opacity: [0.3, 1, 0.3], scaleY: [0.6, 1, 0.6] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        />
      </div>
    </section>
  );
}
