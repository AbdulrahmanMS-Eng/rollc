"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { useLanguage } from "@/providers/LanguageProvider";
import { useCart } from "@/providers/CartProvider";
import { products } from "@/data/products";
import { reveal, viewport } from "@/lib/motion";

interface Props {
  onQuickView: (idx: number) => void;
}

export default function Products({ onQuickView }: Props) {
  const { lang } = useLanguage();
  const { addToCart, showToast } = useCart();

  const handleAddToCart = () => {
    addToCart();
    showToast(lang === "ar" ? "تمت الإضافة إلى السلة" : "Added to your cart");
  };

  const handleFav = () => {
    showToast(lang === "ar" ? "أُضيف إلى المفضلة" : "Added to wishlist");
  };

  return (
    <section className="section products" id="products" style={{ background: "var(--paper)" }}>
      <div className="wrap">
        <motion.div
          className="sec-head"
          variants={reveal}
          initial="hidden"
          whileInView="visible"
          viewport={viewport}
        >
          <div>
            <span className="eyebrow">
              {lang === "ar" ? "قِطعٌ مختارة" : "Curated pieces"}
            </span>
            <h2 className="h-display">
              {lang === "ar" ? "الأكثر طلباً هذا الموسم" : "Most wanted this season"}
            </h2>
          </div>
          <a href="#" className="sec-link">
            <span>{lang === "ar" ? "عرض المتجر كاملاً" : "View full store"}</span>
            <span className="arrow">→</span>
          </a>
        </motion.div>

        <motion.div
          className="prod-grid"
          variants={reveal}
          initial="hidden"
          whileInView="visible"
          viewport={viewport}
        >
          {products.map((p, i) => (
            <article key={i} className="card">
              <div className="card-media">
                {(lang === "ar" ? p.tag.ar : p.tag.en) && (
                  <span className="card-tag">
                    {lang === "ar" ? p.tag.ar : p.tag.en}
                  </span>
                )}
                <button
                  className="card-fav"
                  onClick={handleFav}
                  aria-label={lang === "ar" ? "إضافة للمفضلة" : "Add to wishlist"}
                >
                  <svg viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M12 20s-7-4.5-7-9.5A3.8 3.8 0 0 1 12 7a3.8 3.8 0 0 1 7 3.5C19 15.5 12 20 12 20Z" />
                  </svg>
                </button>
                <Image
                  src={p.img}
                  alt={lang === "ar" ? p.name.ar : p.name.en}
                  width={700}
                  height={700}
                  className="object-cover"
                  style={{ width: "100%", height: "100%" }}
                />
                <button className="quick" onClick={() => onQuickView(i)}>
                  {lang === "ar" ? "عرض سريع" : "Quick view"}
                </button>
              </div>

              <div className="card-body">
                <span className="card-cat">
                  {lang === "ar" ? p.cat.ar : p.cat.en}
                </span>
                <h3 className="card-name">
                  {lang === "ar" ? p.name.ar : p.name.en}
                </h3>
                <p className="card-desc">
                  {lang === "ar" ? p.desc.ar : p.desc.en}
                </p>
                <div className="card-foot">
                  <span className="price">
                    <b>{p.price}</b>{" "}
                    <span className="cur">{lang === "ar" ? "ر.س" : "SAR"}</span>
                    {p.old && <span className="old">{p.old}</span>}
                  </span>
                  <button
                    className="add-cart"
                    onClick={handleAddToCart}
                    aria-label={lang === "ar" ? "أضف إلى السلة" : "Add to cart"}
                  >
                    <svg viewBox="0 0 24 24" aria-hidden="true">
                      <path d="M12 5v14M5 12h14" />
                    </svg>
                  </button>
                </div>
              </div>
            </article>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
