"use client";

import { motion } from "framer-motion";
import { useLanguage } from "@/providers/LanguageProvider";
import { branches } from "@/data/branches";
import { reveal, viewport } from "@/lib/motion";

function PinIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11Z" />
      <circle cx="12" cy="10" r="2.4" />
    </svg>
  );
}

export default function Branches() {
  const { lang } = useLanguage();

  return (
    <section className="section branches" id="branches">
      <div className="wrap">
        <div className="br-inner">
          <motion.div
            className="br-text"
            variants={reveal}
            initial="hidden"
            whileInView="visible"
            viewport={viewport}
          >
            <span className="eyebrow">
              {lang === "ar" ? "زورونا" : "Visit us"}
            </span>
            <h2 className="h-display">
              {lang === "ar" ? "معارضنا تنتظر زيارتك" : "Our showrooms await you"}
            </h2>
            <p>
              {lang === "ar"
                ? "جرّب الراحة بنفسك، والمس الخامات، واحصل على استشارة تصميم مع خبرائنا في أقرب فرعٍ إليك."
                : "Feel the comfort yourself, touch the materials, and get a design consultation with our experts at your nearest showroom."}
            </p>
            <a href="#" className="btn btn--solid" style={{ background: "var(--gold)" }}>
              <span>{lang === "ar" ? "احجز موعد زيارة" : "Book a visit"}</span>
              <span className="arrow">→</span>
            </a>
          </motion.div>

          <motion.div
            className="br-grid"
            variants={reveal}
            initial="hidden"
            whileInView="visible"
            viewport={viewport}
          >
            {branches.map((b) => (
              <article key={b.city.ar} className="br-card">
                <h3 className="br-city">
                  <span className="pin"><PinIcon /></span>
                  <span>{lang === "ar" ? b.city.ar : b.city.en}</span>
                </h3>
                <p className="br-addr">{lang === "ar" ? b.addr.ar : b.addr.en}</p>
                <p className="br-hours">{b.hours}</p>
              </article>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
