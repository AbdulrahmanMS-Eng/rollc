"use client";

import { useState } from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import { useLanguage } from "@/providers/LanguageProvider";
import { reveal, viewport } from "@/lib/motion";

export default function DayNightShowroom() {
  const { lang } = useLanguage();
  const [night, setNight] = useState(false);

  const tagText = night
    ? lang === "ar" ? "الإضاءة مُشعّة" : "Lights on"
    : lang === "ar" ? "الإضاءة مطفأة" : "Lights off";

  return (
    <section className={`section showroom${night ? " night" : ""}`} id="showroom">
      <div className="wrap">
        <motion.div
          className="show-head"
          variants={reveal}
          initial="hidden"
          whileInView="visible"
          viewport={viewport}
        >
          <div>
            <span className="eyebrow">
              {lang === "ar" ? "تجربة المعرض" : "Showroom experience"}
            </span>
            <h2 className="h-display">
              {lang === "ar"
                ? "شاهد غرفتك تتحوّل من النهار إلى الليل"
                : "Watch your room shift from day to night"}
            </h2>
            <p>
              {lang === "ar"
                ? "بدّل بين الوضع النهاري والليلي لترى كيف تُضيء قطع رولك المكان وتمنحه دفئاً سينمائياً."
                : "Toggle between day and night to see how Rollc pieces light up a space with cinematic warmth."}
            </p>
          </div>

          <div className="mode-toggle">
            <span className={`ml${!night ? " on" : ""}`}>
              {lang === "ar" ? "النهار" : "Day"}
            </span>
            <button
              className="switch"
              onClick={() => setNight((n) => !n)}
              aria-label={lang === "ar" ? "تبديل الوضع النهاري والليلي" : "Toggle day / night mode"}
              aria-pressed={night}
            >
              <span className="knob" />
            </button>
            <span className={`ml${night ? " on" : ""}`}>
              {lang === "ar" ? "الليل" : "Night"}
            </span>
          </div>
        </motion.div>

        <motion.div
          className="room"
          variants={reveal}
          initial="hidden"
          whileInView="visible"
          viewport={viewport}
        >
          <Image
            src="https://images.unsplash.com/photo-1616594039964-ae9021a400a0?auto=format&fit=crop&w=1800&q=80"
            alt={lang === "ar" ? "معرض رولك" : "Rollc showroom"}
            fill
            className="room-photo object-cover"
            sizes="100vw"
          />
          <div className="grade-day" />
          <div className="grade-night" />
          <div className="glow center" />
          <div className="glow lamp-l" />
          <div className="glow lamp-r" />
          <div className="glow floor" />
          <span className="bulb b1" />
          <span className="bulb b2" />

          <div className="room-caption">
            <div>
              <p className="rc-name">
                {lang === "ar"
                  ? "جلسة المساء — مجموعة الفخامة"
                  : "Evening lounge — The Opulence Collection"}
              </p>
              <p className="rc-sub">
                {lang === "ar"
                  ? "أريكة، طاولة جانبية، وإضاءة دافئة تُكمل المشهد."
                  : "A sofa, a side table, and warm light that completes the scene."}
              </p>
            </div>
            <span className="rc-tag">{tagText}</span>
          </div>
        </motion.div>

        <p className="show-note">
          {lang === "ar"
            ? "اضغط على المفتاح لإطفاء النهار وإشعال مصابيح الغرفة ✦"
            : "Flip the switch to dim the day and light the room ✦"}
        </p>
      </div>
    </section>
  );
}
