"use client";

import { AnimatePresence, motion } from "framer-motion";
import Image from "next/image";
import { useEffect, useState } from "react";

export default function RollcSplashScreen() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (!sessionStorage.getItem("rollc-opened")) {
      setShow(true);
      sessionStorage.setItem("rollc-opened", "true");

      const timer = setTimeout(() => {
        setShow(false);
      }, 1200);

      return () => clearTimeout(timer);
    }
  }, []);

  return (
    <AnimatePresence>
      {show && (
        <motion.div exit={{ opacity: 0 }} transition={{ duration: 0.3 }} className="fixed inset-0 z-[9999] flex items-center justify-center bg-[#C9A35A]">
          <div className="relative w-[900px] max-w-[92vw] h-[420px]">
            <motion.div initial={{ clipPath: "inset(0 0 0 100%)" }} animate={{ clipPath: "inset(0 0 0 0%)" }} transition={{ duration: 0.75 }} className="absolute inset-x-0 top-0">
              <Image src="/brand/rollc-arc.svg" alt="" width={1000} height={260} priority />
            </motion.div>

            <motion.div initial={{ opacity: 0, scale: 0.4 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.45, duration: 0.25 }} className="absolute left-1/2 top-[-8px] z-20 w-[145px] -translate-x-1/2">
              <Image src="/brand/rollc-star.svg" alt="" width={200} height={200} priority />
            </motion.div>

            <div className="absolute left-1/2 top-[190px] w-[760px] max-w-[90vw] -translate-x-1/2">
              <img src="/brand/rollc-text-final.png?v=final1" alt="Rollc" className="w-full h-auto" />
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
