"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { useLanguage } from "@/providers/LanguageProvider";
import { useCart } from "@/providers/CartProvider";
import { products } from "@/data/products";

const swatchColors = ["#c9b49a", "#4a3b2d", "#2a3338", "#7a6a58"];

interface Props {
  productIdx: number | null;
  onClose: () => void;
}

export default function QuickViewModal({ productIdx, onClose }: Props) {
  const { lang } = useLanguage();
  const { addToCart, showToast } = useCart();
  const [selectedSwatch, setSelectedSwatch] = useState(0);

  const product = productIdx !== null ? products[productIdx] : null;
  const open = productIdx !== null;

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && open) onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  const handleAdd = () => {
    addToCart();
    showToast(lang === "ar" ? "تمت الإضافة إلى السلة" : "Added to your cart");
    onClose();
  };

  return (
    <div
      className={`modal${open ? " open" : ""}`}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      role="dialog"
      aria-modal="true"
      aria-label={lang === "ar" ? "عرض سريع" : "Quick view"}
    >
      <div className="modal-box">
        <div className="modal-img">
          {product && (
            <Image
              src={product.img}
              alt={lang === "ar" ? product.name.ar : product.name.en}
              width={440}
              height={440}
              className="object-cover"
              style={{ width: "100%", height: "100%" }}
            />
          )}
        </div>

        <div className="modal-info">
          <button className="modal-close" onClick={onClose} aria-label={lang === "ar" ? "إغلاق" : "Close"}>✕</button>

          {product && (
            <>
              <span className="m-cat">{lang === "ar" ? product.cat.ar : product.cat.en}</span>
              <h3>{lang === "ar" ? product.name.ar : product.name.en}</h3>
              <div className="m-desc">{lang === "ar" ? product.desc.ar : product.desc.en}</div>
              <div className="m-price">
                {product.price}{" "}
                <span style={{ fontSize: "0.9rem", color: "var(--muted)" }}>
                  {lang === "ar" ? "ر.س" : "SAR"}
                </span>
              </div>

              <div className="m-opts">
                <p className="lbl">{lang === "ar" ? "اختر اللون:" : "Choose colour:"}</p>
                <div className="swatches">
                  {swatchColors.map((color, i) => (
                    <span
                      key={color}
                      className={`swatch${selectedSwatch === i ? " sel" : ""}`}
                      style={{ background: color }}
                      onClick={() => setSelectedSwatch(i)}
                      role="radio"
                      aria-checked={selectedSwatch === i}
                      aria-label={color}
                      tabIndex={0}
                      onKeyDown={(e) => e.key === "Enter" && setSelectedSwatch(i)}
                    />
                  ))}
                </div>
              </div>

              <button className="btn btn--outline" onClick={handleAdd} style={{ width: "100%" }}>
                <span>{lang === "ar" ? "أضف إلى السلة" : "Add to cart"}</span>
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
