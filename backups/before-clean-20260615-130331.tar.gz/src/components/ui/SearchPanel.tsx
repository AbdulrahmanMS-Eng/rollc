"use client";

import { useEffect, useRef } from "react";
import { useLanguage } from "@/providers/LanguageProvider";

const trending = [
  { ar: "أريكة جلد", en: "Leather sofa" },
  { ar: "طاولة رخام", en: "Marble table" },
  { ar: "سرير كنج", en: "King bed" },
  { ar: "كرسي مخمل", en: "Velvet chair" },
  { ar: "مجموعة الفخامة", en: "The Opulence" },
];

interface Props {
  open: boolean;
  onClose: () => void;
}

export default function SearchPanel({ open, onClose }: Props) {
  const { lang } = useLanguage();
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      const t = setTimeout(() => inputRef.current?.focus(), 300);
      return () => clearTimeout(t);
    }
  }, [open]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && open) onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  return (
    <>
      <div className={`search-panel${open ? " open" : ""}`} role="search">
        <div className="sp-row">
          <span className="icon-btn" aria-hidden="true">
            <svg viewBox="0 0 24 24" style={{ width: 22, height: 22, stroke: "var(--brown)", strokeWidth: 1.5, fill: "none" }}>
              <circle cx="11" cy="11" r="7" />
              <path d="m20 20-3.5-3.5" />
            </svg>
          </span>
          <input
            ref={inputRef}
            type="text"
            placeholder={lang === "ar" ? "ابحث عن أريكة، طاولة، سرير…" : "Search sofas, tables, beds…"}
            aria-label={lang === "ar" ? "بحث" : "Search"}
          />
          <button className="sp-close" onClick={onClose} aria-label={lang === "ar" ? "إغلاق" : "Close"}>✕</button>
        </div>
        <div className="sp-tags">
          <span>{lang === "ar" ? "الأكثر بحثاً:" : "Trending:"}</span>
          {trending.map((t) => (
            <a key={t.ar} href="#products" onClick={onClose}>
              {lang === "ar" ? t.ar : t.en}
            </a>
          ))}
        </div>
      </div>
      <div className={`overlay${open ? " open" : ""}`} onClick={onClose} aria-hidden="true" />
    </>
  );
}
