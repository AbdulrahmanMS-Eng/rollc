"use client";

import { useCart } from "@/providers/CartProvider";

export default function Toast() {
  const { toast } = useCart();

  return (
    <div className={`toast${toast.show ? " show" : ""}`} role="status" aria-live="polite">
      <span className="tdot">✦</span>
      <span>{toast.msg}</span>
    </div>
  );
}
