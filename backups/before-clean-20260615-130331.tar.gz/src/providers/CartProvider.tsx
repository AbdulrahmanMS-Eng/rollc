"use client";

import { createContext, useContext, useState, useCallback, useRef, type ReactNode } from "react";

interface CartContextValue {
  count: number;
  addToCart: () => void;
  toast: { msg: string; show: boolean };
  showToast: (msg: string) => void;
}

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [count, setCount] = useState(0);
  const [toast, setToast] = useState({ msg: "", show: false });
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const showToast = useCallback((msg: string) => {
    setToast({ msg, show: true });
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => setToast((t) => ({ ...t, show: false })), 2200);
  }, []);

  const addToCart = useCallback(() => {
    setCount((c) => c + 1);
  }, []);

  return (
    <CartContext.Provider value={{ count, addToCart, toast, showToast }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
