import RollcSplashScreen from "@/components/RollcSplashScreen";
import ClientShell from "@/components/ClientShell";

export default function Home() {
  return (
    <>
      <RollcSplashScreen />
      <ClientShell />
    </>
  );
}
