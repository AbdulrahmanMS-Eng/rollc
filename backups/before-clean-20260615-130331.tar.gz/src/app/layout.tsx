import type { Metadata } from "next";
import { El_Messiri, Tajawal, Cormorant_Garamond, Jost } from "next/font/google";
import "./globals.css";
import { LanguageProvider } from "@/providers/LanguageProvider";
import { CartProvider } from "@/providers/CartProvider";

const elMessiri = El_Messiri({
  variable: "--ff-ar-display",
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

const tajawal = Tajawal({
  variable: "--ff-ar-body",
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "700"],
  display: "swap",
});

const cormorant = Cormorant_Garamond({
  variable: "--ff-en-serif",
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  style: ["normal", "italic"],
  display: "swap",
});

const jost = Jost({
  variable: "--ff-en-sans",
  subsets: ["latin"],
  weight: ["300", "400", "500"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "رولك Rollc — أثاث فاخر يصنع حضور المكان",
  description: "قطعٌ مختارة بعناية، وغرفٌ منسّقة بلمسة فنية، مع خدمة توصيل وتركيب احترافية في جميع أنحاء المملكة.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="ar"
      dir="rtl"
      className={`${elMessiri.variable} ${tajawal.variable} ${cormorant.variable} ${jost.variable}`}
    >
      <body>
        <LanguageProvider>
          <CartProvider>
            {children}
          </CartProvider>
        </LanguageProvider>
      </body>
    </html>
  );
}
