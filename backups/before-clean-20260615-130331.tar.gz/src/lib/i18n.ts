export type Lang = "ar" | "en";
export type Localized = { ar: string; en: string };

export function t(localized: Localized, lang: Lang): string {
  return localized[lang];
}
