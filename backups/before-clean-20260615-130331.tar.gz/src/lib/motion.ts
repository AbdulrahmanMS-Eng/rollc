import type { Variants } from "framer-motion";

export const EASE: [number, number, number, number] = [0.22, 0.61, 0.36, 1];

export const reveal: Variants = {
  hidden: { opacity: 0, y: 34 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 1, ease: EASE },
  },
};

export const viewport = { once: true, margin: "0px 0px -8% 0px" } as const;
