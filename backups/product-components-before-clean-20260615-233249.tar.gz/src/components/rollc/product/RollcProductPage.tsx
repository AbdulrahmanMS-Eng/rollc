"use client";

import { useMemo, useState } from "react";
import { TopBar } from "@/components/rollc/layout/TopBar";
import { Header } from "@/components/rollc/layout/Header";
import { Footer } from "@/components/rollc/layout/Footer";
import { RollcProvider, useRollcStore } from "@/components/rollc/ui/RollcStore";
import { SearchPanel } from "@/components/rollc/ui/SearchPanel";
import { QuickViewModal } from "@/components/rollc/ui/QuickViewModal";
import { Toast } from "@/components/rollc/ui/Toast";
import { currency, products, type Locale, type Product } from "@/data/rollc/content";

function productUrl(locale: Locale, product: Product) {
  return locale === "ar" ? `/products/${product.id}` : `/en/products/${product.id}`;
}

function highRes(src: string) {
  return src.replace("w=700", "w=1200").replace("w=300", "w=1200");
}

function productDimensions(product: Product, locale: Locale) {
  const dimensions: Record<string, { ar: string[]; en: string[] }> = {
    "milano-sofa": {
      ar: ["العرض: 240 سم", "العمق: 95 سم", "الارتفاع: 82 سم", "ارتفاع المقعد: 44 سم", "عدد المقاعد: 3"],
      en: ["Width: 240 cm", "Depth: 95 cm", "Height: 82 cm", "Seat height: 44 cm", "Seats: 3"],
    },
    "oslo-chair": {
      ar: ["العرض: 78 سم", "العمق: 82 سم", "الارتفاع: 86 سم", "ارتفاع المقعد: 45 سم", "عدد المقاعد: 1"],
      en: ["Width: 78 cm", "Depth: 82 cm", "Height: 86 cm", "Seat height: 45 cm", "Seats: 1"],
    },
    "nordic-table": {
      ar: ["العرض: 120 سم", "العمق: 65 سم", "الارتفاع: 42 سم", "الخامة: رخام وخشب", "الاستخدام: طاولة قهوة"],
      en: ["Width: 120 cm", "Depth: 65 cm", "Height: 42 cm", "Material: marble & wood", "Use: coffee table"],
    },
    "serene-bed": {
      ar: ["العرض: 200 سم", "الطول: 220 سم", "الارتفاع: 110 سم", "المقاس: كنج", "الخامة: قماش منجّد"],
      en: ["Width: 200 cm", "Length: 220 cm", "Height: 110 cm", "Size: king", "Material: upholstered fabric"],
    },
    "roma-sofa": {
      ar: ["العرض: 285 سم", "العمق: 165 سم", "الارتفاع: 84 سم", "التكوين: زاوية L", "عدد المقاعد: 4"],
      en: ["Width: 285 cm", "Depth: 165 cm", "Height: 84 cm", "Configuration: L sectional", "Seats: 4"],
    },
    "copenhagen-chair": {
      ar: ["العرض: 72 سم", "العمق: 78 سم", "الارتفاع: 80 سم", "ارتفاع المقعد: 44 سم", "عدد المقاعد: 1"],
      en: ["Width: 72 cm", "Depth: 78 cm", "Height: 80 cm", "Seat height: 44 cm", "Seats: 1"],
    },
    "arabesque-dining": {
      ar: ["العرض: 220 سم", "العمق: 100 سم", "الارتفاع: 76 سم", "عدد المقاعد: 8", "الخامة: خشب طبيعي"],
      en: ["Width: 220 cm", "Depth: 100 cm", "Height: 76 cm", "Seats: 8", "Material: natural wood"],
    },
    "amber-lamp": {
      ar: ["العرض: 38 سم", "العمق: 38 سم", "الارتفاع: 158 سم", "نوع الإضاءة: دافئة", "الاستخدام: أرضي"],
      en: ["Width: 38 cm", "Depth: 38 cm", "Height: 158 cm", "Light: warm", "Use: floor lamp"],
    },
  };

  return dimensions[product.id]?.[locale] ?? (
    locale === "ar"
      ? ["الأبعاد تختلف حسب التكوين المختار"]
      : ["Dimensions vary by selected configuration"]
  );
}

function ProductDetailContent({ locale, product }: { locale: Locale; product: Product }) {
  const { addToCart, showToast, openQuickView } = useRollcStore();
  const [activeImage, setActiveImage] = useState(highRes(product.img));
  const [qty, setQty] = useState(1);
  const [saved, setSaved] = useState(false);
  const [openAcc, setOpenAcc] = useState(0);

  const gallery = useMemo(() => [
    highRes(product.img),
    "https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=1200&q=80",
    "https://images.unsplash.com/photo-1567016432779-094069958ea5?auto=format&fit=crop&w=1200&q=80",
    "https://images.unsplash.com/photo-1540574163026-643ea20ade25?auto=format&fit=crop&w=1200&q=80",
  ], [product.img]);

  const related = products.filter((p) => p.id !== product.id).slice(0, 4);
  const similar = products.filter((p) => p.id !== product.id && p.cat.en === product.cat.en).slice(0, 4);
  const fallbackSimilar = similar.length ? similar : related;

  const addSelected = () => {
    for (let i = 0; i < qty; i += 1) addToCart();
    showToast(locale === "ar" ? `تمت إضافة ${product.name.ar} إلى السلة` : `${product.name.en} added to cart`);
  };

  const acc = [
    {
      title: { ar: "الخامات", en: "Materials" },
      body: {
        ar: "خامات منتقاة بعناية، مع تشطيب فاخر يوازن بين الجمال والمتانة والاستخدام اليومي.",
        en: "Carefully selected materials with a refined finish that balances beauty, durability, and everyday use.",
      },
    },
    {
      title: { ar: "العناية والتنظيف", en: "Care & cleaning" },
      body: {
        ar: "يُنظّف بقطعة قماش ناعمة وجافة، وتُتجنّب أشعة الشمس المباشرة لفترات طويلة للحفاظ على اللون والخامة.",
        en: "Clean with a soft dry cloth and avoid prolonged direct sunlight to preserve the colour and material.",
      },
    },
    {
      title: { ar: "التوصيل والتركيب", en: "Delivery & installation" },
      body: {
        ar: "توصيل احترافي داخل المملكة مع تركيب بواسطة فريق متخصص في الموعد المناسب لك.",
        en: "Professional delivery across Saudi Arabia with installation by a specialised team at a time that suits you.",
      },
    },
    {
      title: { ar: "الضمان والإرجاع", en: "Warranty & returns" },
      body: {
        ar: "ضمان يغطي عيوب التصنيع، مع إمكانية الاستبدال أو الإرجاع حسب سياسة المتجر.",
        en: "Warranty covers manufacturing defects, with exchange or return according to store policy.",
      },
    },
  ];

  return (
    <>
      <div className="wrap">
        <nav className="pdp-crumb" aria-label={locale === "ar" ? "مسار التنقل" : "Breadcrumb"}>
          <a href={locale === "ar" ? "/" : "/en"}>{locale === "ar" ? "الرئيسية" : "Home"}</a>
          <span>/</span>
          <a href={locale === "ar" ? "/#products" : "/en#products"}>{product.cat[locale]}</a>
          <span>/</span>
          <b>{product.name[locale]}</b>
        </nav>

        <section className="pdp-hero">
          <div className="pdp-gallery">
            <div className="pdp-main-img">
              {product.tag[locale] ? <span className="pdp-badge">{product.tag[locale]}</span> : null}
              <button
                className={`pdp-save${saved ? " active" : ""}`}
                onClick={() => {
                  setSaved((v) => !v);
                  showToast(saved ? (locale === "ar" ? "أُزيلت من المفضلة" : "Removed from wishlist") : (locale === "ar" ? "أُضيفت إلى المفضلة" : "Added to wishlist"));
                }}
                aria-label={locale === "ar" ? "المفضلة" : "Wishlist"}
              >
                <svg viewBox="0 0 24 24"><path d="M12 20s-7-4.5-7-9.5A3.8 3.8 0 0 1 12 7a3.8 3.8 0 0 1 7 3.5C19 15.5 12 20 12 20Z" /></svg>
              </button>
              <img src={activeImage} alt={product.name[locale]} />
            </div>

            <div className="pdp-thumbs">
              {gallery.map((src, index) => (
                <button
                  key={`${product.id}-${index}`}
                  className={activeImage === src ? "active" : ""}
                  onClick={() => setActiveImage(src)}
                  aria-label={locale === "ar" ? `صورة ${index + 1}` : `Image ${index + 1}`}
                >
                  <img src={src.replace("w=1200", "w=300")} alt="" />
                </button>
              ))}
            </div>
          </div>

          <aside className="pdp-panel">
            <span className="pdp-eyebrow">{product.cat[locale]}</span>
            <h1>{product.name[locale]}</h1>
            <p className="pdp-sub">{locale === "ar" ? product.name.en : product.name.ar}</p>

            <div className="pdp-rating">
              <span>★★★★★</span>
              <b>{locale === "ar" ? "4.9 · 128 تقييماً" : "4.9 · 128 reviews"}</b>
            </div>

            <div className="pdp-price">
              <strong>{product.price}<small>{currency(locale)}</small></strong>
              {product.old ? <del>{product.old} {currency(locale)}</del> : null}
              {product.old ? <em>{locale === "ar" ? "عرض خاص" : "Special offer"}</em> : null}
            </div>

            <p className="pdp-desc">{product.desc[locale]}</p>

            <div className="pdp-options">
              <h3>{locale === "ar" ? "اللون" : "Colour"}</h3>
              <div className="pdp-colors">
                {["#cdb593", "#5a4330", "#8c8a84", "#5c6044"].map((color, index) => (
                  <button key={color} className={index === 0 ? "active" : ""} style={{ background: color }} aria-label="color" />
                ))}
              </div>
            </div>

            <div className="pdp-options">
              <h3>{locale === "ar" ? "المقاس / التكوين" : "Size / configuration"}</h3>
              <div className="pdp-sizes">
                {(locale === "ar" ? ["2 مقعد", "3 مقاعد", "زاوية L"] : ["2 seats", "3 seats", "L sectional"]).map((size, index) => (
                  <button key={size} className={index === 1 ? "active" : ""}>{size}</button>
                ))}
              </div>
            </div>

            <div className="pdp-buy">
              <div className="pdp-qty">
                <button onClick={() => setQty((v) => Math.max(1, v - 1))}>−</button>
                <span>{qty}</span>
                <button onClick={() => setQty((v) => Math.min(99, v + 1))}>+</button>
              </div>
              <button className="pdp-cart" onClick={addSelected}>{locale === "ar" ? "أضف إلى السلة" : "Add to cart"}</button>
            </div>

            <button className="pdp-consult" onClick={() => showToast(locale === "ar" ? "سيتواصل معك مستشار التصميم قريباً ✦" : "A design consultant will contact you soon ✦")}>
              {locale === "ar" ? "احجز استشارة تصميم" : "Book a design consultation"}
            </button>

            <div className="pdp-trust">
              <span>{locale === "ar" ? "متوفر للطلب — يصل خلال 5 إلى 10 أيام" : "Available to order — arrives in 5 to 10 days"}</span>
              <span>{locale === "ar" ? "توصيل وتركيب احترافي داخل المملكة" : "Professional delivery & installation across Saudi Arabia"}</span>
              <div><b>Mada</b><b>Visa</b><b>Apple Pay</b><b>Mastercard</b></div>
            </div>
          </aside>
        </section>
      </div>


      <section className="section specs">
        <div className="wrap">
          <div className="spec-grid">
            <div className="spec">
              <div className="si">
                <svg viewBox="0 0 24 24"><path d="M4 7c4-3 12-3 16 0M4 7v10c4 3 12 3 16 0V7M4 12c4 3 12 3 16 0" /></svg>
              </div>
              <div className="st">{locale === "ar" ? "قماش مخملي فاخر" : "Premium velvet"}</div>
            </div>

            <div className="spec">
              <div className="si">
                <svg viewBox="0 0 24 24"><path d="M4 9h16M4 9 6 4h12l2 5M4 9v11h16V9M9 13v4M15 13v4" /></svg>
              </div>
              <div className="st">{locale === "ar" ? "هيكل خشب طبيعي" : "Natural wood frame"}</div>
            </div>

            <div className="spec">
              <div className="si">
                <svg viewBox="0 0 24 24"><path d="M12 3 4 6v6c0 4 3.5 7.5 8 9 4.5-1.5 8-5 8-9V6l-8-3Z" /><path d="m9 12 2 2 4-4" /></svg>
              </div>
              <div className="st">{locale === "ar" ? "ضمان سنتين" : "2-year warranty"}</div>
            </div>

            <div className="spec">
              <div className="si">
                <svg viewBox="0 0 24 24"><path d="M12 2v6m0 0 3-3m-3 3L9 5M5 13h14l-1.5 8h-11L5 13Z" /></svg>
              </div>
              <div className="st">{locale === "ar" ? "تركيب مجاني" : "Free installation"}</div>
            </div>

            <div className="spec">
              <div className="si">
                <svg viewBox="0 0 24 24"><path d="M3 10h18M5 10V7a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v3M4 10v8M20 10v8M4 16h16" /></svg>
              </div>
              <div className="st">{locale === "ar" ? "مناسب لغرف المعيشة" : "Ideal for living rooms"}</div>
            </div>

            <div className="spec">
              <div className="si">
                <svg viewBox="0 0 24 24"><path d="m12 2 2.4 4.9 5.4.8-3.9 3.8.9 5.4-4.8-2.5-4.8 2.5.9-5.4L4.2 7.7l5.4-.8L12 2Z" /></svg>
              </div>
              <div className="st">{locale === "ar" ? "صُنع بجودة عالية" : "Crafted to last"}</div>
            </div>
          </div>
        </div>
      </section>


      <section className="pdp-section">
        <div className="wrap pdp-story">
          <div>
            <span className="pdp-eyebrow">{locale === "ar" ? "قصة القطعة" : "The story"}</span>
            <h2>{locale === "ar" ? "فخامة مصممة لحضور يومي" : "Luxury designed for everyday presence"}</h2>
            <p>
              {locale === "ar"
                ? "صُممت هذه القطعة لتكون جزءاً من مشهد منزلي دافئ وراقي، تجمع بين الراحة العملية والتفاصيل الجمالية التي تصنع فرقاً في المكان."
                : "This piece is designed to become part of a warm, refined home scene, combining everyday comfort with aesthetic details that elevate the space."}
            </p>
            <blockquote>{locale === "ar" ? "ليست مجرد قطعة أثاث، بل حضورٌ يغيّر إحساس المكان." : "Not just furniture, but a presence that changes how the room feels."}</blockquote>
          </div>
          <img src={highRes(product.img)} alt={product.name[locale]} />
        </div>
      </section>

      <section className="pdp-section pdp-dims-section">
        <div className="wrap pdp-dims">
          <div>
            <span className="pdp-eyebrow">{locale === "ar" ? "المقاسات" : "Dimensions"}</span>
            <h2>{locale === "ar" ? "مقاسات تناسب مساحتك" : "Measurements that fit your space"}</h2>
            <div className="pdp-dim-list">
              {productDimensions(product, locale).map((dim) => {
                const [k, v] = dim.split(":");
                return <div key={dim}><span>{k}</span><b>{v ?? ""}</b></div>;
              })}
            </div>
          </div>
          <div className="pdp-diagram">
            <svg viewBox="0 0 420 260" role="img" aria-label={locale === "ar" ? "رسم توضيحي للأبعاد" : "Dimension diagram"}>
              <rect x="70" y="95" width="280" height="70" rx="12" />
              <rect x="70" y="60" width="34" height="120" rx="10" />
              <rect x="316" y="60" width="34" height="120" rx="10" />
              <line x1="70" y1="35" x2="350" y2="35" />
              <line x1="365" y1="60" x2="365" y2="180" />
              <text x="210" y="25" textAnchor="middle">{locale === "ar" ? "العرض" : "Width"}</text>
              <text x="388" y="125" textAnchor="middle">{locale === "ar" ? "الارتفاع" : "Height"}</text>
            </svg>
          </div>
        </div>
      </section>

      <section className="pdp-section">
        <div className="wrap">
          <div className="pdp-centered-head">
            <span className="pdp-eyebrow">{locale === "ar" ? "التفاصيل الكاملة" : "Full details"}</span>
            <h2>{locale === "ar" ? "كل ما تود معرفته" : "Everything you want to know"}</h2>
          </div>

          <div className="pdp-accordion">
            {acc.map((item, index) => (
              <div className={`pdp-acc-item${openAcc === index ? " open" : ""}`} key={item.title.en}>
                <button onClick={() => setOpenAcc(openAcc === index ? -1 : index)}>
                  <span>{item.title[locale]}</span>
                  <b>{openAcc === index ? "−" : "+"}</b>
                </button>
                {openAcc === index ? <p>{item.body[locale]}</p> : null}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="pdp-section pdp-room-section">
        <div className="wrap pdp-room">
          <div className="pdp-room-img">
            <img src="https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1200&q=80" alt="" />
          </div>
          <div>
            <span className="pdp-eyebrow">{locale === "ar" ? "جلسة منسقة" : "Styled set"}</span>
            <h2>{locale === "ar" ? "أكمل المشهد حول هذه القطعة" : "Complete the scene around this piece"}</h2>
            <p>{locale === "ar" ? "قطع مختارة بعناية لتنسجم مع المنتج وتمنح الغرفة حضوراً متكاملاً." : "Hand-picked pieces to pair beautifully with the product and complete the room."}</p>
            {related.slice(0, 3).map((item) => (
              <a className="pdp-mini-product" href={productUrl(locale, item)} key={item.id}>
                <img src={item.img} alt={item.name[locale]} />
                <span>{item.name[locale]}</span>
                <b>{item.price} {currency(locale)}</b>
              </a>
            ))}
          </div>
        </div>
      </section>

      <section className="pdp-section">
        <div className="wrap">
          <div className="pdp-reviews-head">
            <div>
              <span className="pdp-eyebrow">{locale === "ar" ? "آراء العملاء" : "Customer reviews"}</span>
              <h2>{locale === "ar" ? "تجارب تروي الجودة" : "Experiences that speak quality"}</h2>
            </div>
            <strong>4.9</strong>
          </div>
          <div className="pdp-review-grid">
            {(locale === "ar"
              ? ["الجودة فاقت توقعاتي، والتوصيل كان احترافياً.", "الخامة جميلة واللون أضاف فخامة للمكان.", "خدمة ممتازة وساعدوني في اختيار المقاس المناسب."]
              : ["The quality exceeded my expectations and delivery was professional.", "The material is beautiful and the colour elevated the room.", "Excellent service and they helped me choose the right size."]
            ).map((review, index) => <article key={review}><span>★★★★★</span><p>{review}</p><b>{locale === "ar" ? `عميل موثق ${index + 1}` : `Verified customer ${index + 1}`}</b></article>)}
          </div>
        </div>
      </section>

      <ProductGrid
        locale={locale}
        title={locale === "ar" ? "قطع تنسجم مع المنتج" : "Pieces that pair beautifully"}
        eyebrow={locale === "ar" ? "قد يعجبك أيضاً" : "You may also like"}
        products={related}
      />

      <ProductGrid
        locale={locale}
        title={locale === "ar" ? `المزيد من ${product.cat.ar}` : `More ${product.cat.en}`}
        eyebrow={locale === "ar" ? `${product.cat.ar} أخرى من رولك` : `More from Rollc`}
        products={fallbackSimilar}
      />
    </>
  );
}

function ProductGrid({ locale, eyebrow, title, products: items }: { locale: Locale; eyebrow: string; title: string; products: Product[] }) {
  return (
    <section className="pdp-section pdp-related">
      <div className="wrap">
        <div className="pdp-sec-head">
          <div>
            <span className="pdp-eyebrow">{eyebrow}</span>
            <h2>{title}</h2>
          </div>
          <a href={locale === "ar" ? "/#products" : "/en#products"}>{locale === "ar" ? "عرض الكل" : "View all"} →</a>
        </div>

        <div className="pdp-product-grid">
          {items.map((item) => (
            <a className="pdp-card" href={productUrl(locale, item)} key={item.id}>
              <div>
                {item.tag[locale] ? <span>{item.tag[locale]}</span> : null}
                <img src={item.img} alt={item.name[locale]} />
              </div>
              <section>
                <small>{item.cat[locale]}</small>
                <h3>{item.name[locale]}</h3>
                <b>{item.price} {currency(locale)}</b>
              </section>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

export function RollcProductPage({ locale, product }: { locale: Locale; product: Product }) {
  return (
    <RollcProvider locale={locale}>
      <main
        className={locale === "en" ? "rollc-real-page lang-en" : "rollc-real-page"}
        dir={locale === "ar" ? "rtl" : "ltr"}
      >
        <TopBar locale={locale} />
        <Header locale={locale} />
        <ProductDetailContent locale={locale} product={product} />
        <Footer locale={locale} />
        <SearchPanel />
        <QuickViewModal />
        <Toast />
      </main>
    </RollcProvider>
  );
}
