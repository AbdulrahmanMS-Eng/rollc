"use client";

import { useEffect, useMemo, useState } from "react";
import type { Locale } from "@/data/rollc/content";

type L10n = { ar: string; en: string };

type ProductMini = {
  cat?: L10n;
  name: L10n;
  price: string;
  tag?: L10n;
  img: string;
  desc?: L10n;
};

const gallery = [
  {
    src: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=80",
    thumb: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=300&q=80",
    alt: { ar: "زاوية أمامية", en: "Front angle" },
  },
  {
    src: "https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=1200&q=80",
    thumb: "https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=300&q=80",
    alt: { ar: "زاوية جانبية", en: "Side angle" },
  },
  {
    src: "https://images.unsplash.com/photo-1567016432779-094069958ea5?auto=format&fit=crop&w=1200&q=80",
    thumb: "https://images.unsplash.com/photo-1567016432779-094069958ea5?auto=format&fit=crop&w=300&q=80",
    alt: { ar: "مشهد غرفة", en: "Room scene" },
  },
  {
    src: "https://images.unsplash.com/photo-1540574163026-643ea20ade25?auto=format&fit=crop&w=1200&q=80",
    thumb: "https://images.unsplash.com/photo-1540574163026-643ea20ade25?auto=format&fit=crop&w=300&q=80",
    alt: { ar: "تفاصيل الخامة", en: "Fabric details" },
  },
];

const related: ProductMini[] = [
  {
    cat: { ar: "كراسي", en: "Chairs" },
    name: { ar: "كرسي أوسلو", en: "Oslo Chair" },
    price: "1,750",
    tag: { ar: "جديد", en: "New" },
    img: "https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&w=700&q=80",
  },
  {
    cat: { ar: "طاولات", en: "Tables" },
    name: { ar: "طاولة نورديك", en: "Nordic Table" },
    price: "2,900",
    tag: { ar: "", en: "" },
    img: "https://images.unsplash.com/photo-1532372320572-cda25653a26d?auto=format&fit=crop&w=700&q=80",
  },
  {
    cat: { ar: "ديكور", en: "Decor" },
    name: { ar: "مصباح أمبر", en: "Amber Lamp" },
    price: "890",
    tag: { ar: "عرض", en: "Offer" },
    img: "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&w=700&q=80",
  },
  {
    cat: { ar: "أرائك", en: "Sofas" },
    name: { ar: "أريكة روما", en: "Roma Sofa" },
    price: "6,800",
    tag: { ar: "فاخر", en: "Premium" },
    img: "https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=700&q=80",
  },
];

const sofas: ProductMini[] = [
  {
    name: { ar: "أريكة روما", en: "Roma Sofa" },
    price: "6,800",
    tag: { ar: "فاخر", en: "Premium" },
    img: "https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=700&q=80",
  },
  {
    name: { ar: "أريكة أوسلو", en: "Oslo Sofa" },
    price: "3,950",
    tag: { ar: "جديد", en: "New" },
    img: "https://images.unsplash.com/photo-1567016432779-094069958ea5?auto=format&fit=crop&w=700&q=80",
  },
  {
    name: { ar: "أريكة سرين", en: "Serene Sofa" },
    price: "5,200",
    tag: { ar: "", en: "" },
    img: "https://images.unsplash.com/photo-1540574163026-643ea20ade25?auto=format&fit=crop&w=700&q=80",
  },
  {
    name: { ar: "أريكة كوبنهاغن", en: "Copenhagen Sofa" },
    price: "4,600",
    tag: { ar: "عرض", en: "Offer" },
    img: "https://images.unsplash.com/photo-1550226891-ef816aed4a98?auto=format&fit=crop&w=700&q=80",
  },
];

function t(locale: Locale, value: L10n) {
  return value[locale];
}

function StarRating({ id }: { id?: string }) {
  return (
    <span className="stars" id={id}>
      {Array.from({ length: 5 }).map((_, index) => (
        <svg key={index} viewBox="0 0 24 24" aria-hidden="true">
          <path d="m12 2 2.9 6.3 6.9.6-5.2 4.6 1.6 6.7L12 17.3 5.8 20.8l1.6-6.7L2.2 8.9l6.9-.6L12 2Z" />
        </svg>
      ))}
    </span>
  );
}

function HeartIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M12 20s-7-4.5-7-9.5A3.8 3.8 0 0 1 12 7a3.8 3.8 0 0 1 7 3.5C19 15.5 12 20 12 20Z" />
    </svg>
  );
}

function BagIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M6 7h12l-1 13H7L6 7Z" />
      <path d="M9 7a3 3 0 0 1 6 0" />
    </svg>
  );
}

function SearchIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-3.5-3.5" />
    </svg>
  );
}

function PinIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11Z" />
      <circle cx="12" cy="10" r="2.4" />
    </svg>
  );
}

function CheckIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="m5 12 4.5 4.5L19 7" />
    </svg>
  );
}

export function ProductExactPage({ locale }: { locale: Locale }) {
  const [activeImage, setActiveImage] = useState(gallery[0].src);
  const [cart, setCart] = useState(0);
  const [qty, setQty] = useState(1);
  const [saved, setSaved] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [stickyBar, setStickyBar] = useState(false);
  const [activeColor, setActiveColor] = useState(0);
  const [activeSize, setActiveSize] = useState(1);
  const [openAcc, setOpenAcc] = useState(0);
  const [toast, setToast] = useState("");
  const [newsletter, setNewsletter] = useState("");
  const [newsletterMsg, setNewsletterMsg] = useState("");

  const colors = useMemo(
    () => [
      { ar: "رملي فاخر", en: "Sand", color: "#cdb593" },
      { ar: "بني عميق", en: "Deep Brown", color: "#5a4330" },
      { ar: "رمادي حجري", en: "Stone Grey", color: "#8c8a84" },
      { ar: "أخضر زيتي", en: "Olive", color: "#5c6044" },
    ],
    [],
  );

  const sizes = useMemo(
    () => [
      { ar: "2 مقعد", en: "2 Seater" },
      { ar: "3 مقاعد", en: "3 Seater" },
      { ar: "زاوية L", en: "L-Corner" },
    ],
    [],
  );

  const addToast = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 2600);
  };

  const addToCart = (message?: string) => {
    setCart((value) => value + 1);
    addToast(message ?? (locale === "ar" ? "تمت إضافة أريكة ميلانو إلى السلة" : "Milano Sofa added to cart"));
  };

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 30);
      setStickyBar(window.innerWidth <= 760 && window.scrollY > 700);
    };

    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  useEffect(() => {
    const elements = Array.from(document.querySelectorAll(".product-exact-page .reveal"));
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("in");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -7% 0px" },
    );

    elements.forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, []);

  const goLang = (nextLocale: Locale) => {
    window.location.href = nextLocale === "ar" ? "/products/milano-sofa" : "/en/products/milano-sofa";
  };

  return (
    <div className={`product-exact-page${locale === "en" ? " lang-en" : ""}`} dir={locale === "ar" ? "rtl" : "ltr"}>
      <div className="topbar">
        {locale === "ar" ? (
          <span>
            توصيل وتركيب احترافي لكل أنحاء المملكة — <b>استشارة تصميم مجانية</b>
          </span>
        ) : (
          <span>
            Professional delivery & installation Kingdom-wide — <b>Free design consultation</b>
          </span>
        )}
      </div>

      <header className={`header${scrolled ? " scrolled" : ""}`} id="header">
        <div className="wrap">
          <nav className="nav">
            <a href={locale === "ar" ? "/" : "/en"} className="brand" aria-label="Rollc رولك">
              <span className="mark">
                Roll<b>c</b>
              </span>
              <span className="ar">رولـك</span>
            </a>

            <ul className="menu">
              <li><a href={locale === "ar" ? "/" : "/en"}>{locale === "ar" ? "الرئيسية" : "Home"}</a></li>
              <li><a href="#" className="cur">{locale === "ar" ? "غرف المعيشة" : "Living"}</a></li>
              <li><a href="#">{locale === "ar" ? "غرف النوم" : "Bedroom"}</a></li>
              <li><a href="#">{locale === "ar" ? "طاولات" : "Tables"}</a></li>
              <li><a href="#">{locale === "ar" ? "ديكور" : "Decor"}</a></li>
              <li><a href="#">{locale === "ar" ? "العروض" : "Offers"}</a></li>
              <li><a href="#branches">{locale === "ar" ? "الفروع" : "Showrooms"}</a></li>
            </ul>

            <div className="actions">
              <button className="icon-btn" onClick={() => setSearchOpen(true)} aria-label={locale === "ar" ? "بحث" : "Search"}>
                <SearchIcon />
              </button>
              <button
                className="icon-btn"
                onClick={() => addToast(cart ? (locale === "ar" ? `لديك ${cart} منتج في السلة` : `${cart} item(s) in your cart`) : (locale === "ar" ? "سلتك فارغة" : "Your cart is empty"))}
                aria-label={locale === "ar" ? "السلة" : "Cart"}
              >
                <BagIcon />
                <span className="cart-count" id="cartCount">{cart}</span>
              </button>
              <div className="lang-switch" role="group" aria-label="Language">
                <button className={locale === "ar" ? "active" : ""} onClick={() => goLang("ar")}>ع</button>
                <button className={locale === "en" ? "active" : ""} onClick={() => goLang("en")}>EN</button>
              </div>
              <a href="#related" className="cta-shop">{locale === "ar" ? "تسوّق الآن" : "Shop now"}</a>
              <button className={`burger${mobileOpen ? " open" : ""}`} onClick={() => setMobileOpen((value) => !value)} aria-label={locale === "ar" ? "القائمة" : "Menu"}>
                <span />
                <span />
                <span />
              </button>
            </div>
          </nav>
        </div>
      </header>

      <div className={`mobile-nav${mobileOpen ? " open" : ""}`} id="mobileNav">
        <button className="mn-close" onClick={() => setMobileOpen(false)} aria-label={locale === "ar" ? "إغلاق" : "Close"}>✕</button>
        {(locale === "ar" ? ["الرئيسية", "غرف المعيشة", "غرف النوم", "طاولات", "ديكور", "العروض", "الفروع"] : ["Home", "Living", "Bedroom", "Tables", "Decor", "Offers", "Showrooms"]).map((item) => (
          <a href={item === "الفروع" || item === "Showrooms" ? "#branches" : "#"} key={item} onClick={() => setMobileOpen(false)}>{item}</a>
        ))}
      </div>

      <div className="wrap">
        <nav className="crumb" aria-label={locale === "ar" ? "مسار التنقل" : "Breadcrumb"}>
          <a href={locale === "ar" ? "/" : "/en"}>{locale === "ar" ? "الرئيسية" : "Home"}</a><span className="sep">/</span>
          <a href="#">{locale === "ar" ? "الأرائك" : "Sofas"}</a><span className="sep">/</span>
          <span className="now">{locale === "ar" ? "أريكة ميلانو" : "Milano Sofa"}</span>
        </nav>
      </div>

      <main className="wrap">
        <section className="pdp">
          <div className="gallery">
            <div className="g-main">
              <span className="g-badge">{locale === "ar" ? "الأكثر مبيعاً · Best Seller" : "Best Seller"}</span>
              <button
                className={`g-save${saved ? " active" : ""}`}
                onClick={() => {
                  setSaved((value) => !value);
                  addToast(saved ? (locale === "ar" ? "أُزيلت من المفضلة" : "Removed from wishlist") : (locale === "ar" ? "أُضيفت إلى المفضلة" : "Added to wishlist"));
                }}
                aria-label={locale === "ar" ? "إضافة للمفضلة" : "Wishlist"}
              >
                <HeartIcon />
              </button>
              <button className="g-zoom" onClick={() => window.open(activeImage, "_blank")}>
                <SearchIcon /> <span>{locale === "ar" ? "تكبير" : "Zoom"}</span>
              </button>
              <img id="mainImg" src={activeImage} alt={locale === "ar" ? "أريكة ميلانو — زاوية أمامية" : "Milano Sofa — front angle"} />
            </div>
            <div className="thumbs" id="thumbs">
              {gallery.map((item) => (
                <button
                  key={item.src}
                  className={`thumb${activeImage === item.src ? " active" : ""}`}
                  onClick={() => setActiveImage(item.src)}
                  aria-label={t(locale, item.alt)}
                >
                  <img src={item.thumb} alt={t(locale, item.alt)} />
                </button>
              ))}
            </div>
          </div>

          <div className="panel">
            <span className="p-eyebrow">{locale === "ar" ? "أرائك · Sofas" : "Sofas"}</span>
            <h1 className="p-title">{locale === "ar" ? "أريكة ميلانو" : "Milano Sofa"}</h1>
            <p className="p-sub">{locale === "ar" ? "Milano Sofa" : "أريكة ميلانو"}</p>
            <div className="p-rating">
              <StarRating id="starsTop" />
              <span>{locale === "ar" ? "4.9 · 128 تقييماً" : "4.9 · 128 reviews"}</span>
            </div>
            <div className="p-price">
              <span className="now">4,250<span className="cur">{locale === "ar" ? "ر.س" : "SAR"}</span></span>
              <span className="old">{locale === "ar" ? "4,990 ر.س" : "4,990 SAR"}</span>
              <span className="save">{locale === "ar" ? "وفّر 740 ر.س" : "Save 740 SAR"}</span>
            </div>
            <p className="p-desc">
              {locale === "ar"
                ? "أريكة ثلاثية فاخرة بقماش مخملي ناعم، مصممة لتمنح غرفة المعيشة حضوراً دافئاً وراقياً."
                : "A luxurious three-seater in soft velvet, designed to give your living room a warm, refined presence."}
            </p>

            <div className="opt">
              <div className="opt-head"><span className="opt-label">{locale === "ar" ? "اللون" : "Colour"}</span><span className="opt-value" id="colorVal">{colors[activeColor][locale]}</span></div>
              <div className="colors" id="colors">
                {colors.map((item, index) => (
                  <button key={item.color} className={`color${activeColor === index ? " active" : ""}`} onClick={() => setActiveColor(index)}>
                    <span className="dot" style={{ background: item.color }} />
                    <span className="nm">{item[locale]}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="opt">
              <div className="opt-head"><span className="opt-label">{locale === "ar" ? "المقاس / التكوين" : "Size / Configuration"}</span><span className="opt-value" id="sizeVal">{sizes[activeSize][locale]}</span></div>
              <div className="sizes" id="sizes">
                {sizes.map((item, index) => (
                  <button key={item.en} className={`size${activeSize === index ? " active" : ""}`} onClick={() => setActiveSize(index)}>{item[locale]}</button>
                ))}
              </div>
            </div>

            <div className="buy-row">
              <div className="qty">
                <button onClick={() => setQty((value) => Math.max(1, value - 1))} aria-label={locale === "ar" ? "إنقاص" : "Decrease"}>−</button>
                <span className="q-val" id="qty">{qty}</span>
                <button onClick={() => setQty((value) => Math.min(99, value + 1))} aria-label={locale === "ar" ? "زيادة" : "Increase"}>+</button>
              </div>
              <button className="add-cart" onClick={() => addToCart()}>
                <BagIcon /><span>{locale === "ar" ? "أضف إلى السلة" : "Add to cart"}</span>
              </button>
            </div>
            <button className="consult" onClick={() => addToast(locale === "ar" ? "سيتواصل معك مستشار التصميم قريباً ✦" : "Our design consultant will contact you soon ✦")}>
              <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V6a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z" /></svg>
              <span>{locale === "ar" ? "احجز استشارة تصميم" : "Book a design consultation"}</span>
            </button>

            <div className="meta-line stock"><span className="dot" /><span>{locale === "ar" ? <><b>متوفر للطلب</b> — يصل خلال 5 إلى 10 أيام</> : <><b>Available to order</b> — arrives in 5 to 10 days</>}</span></div>
            <div className="meta-line"><span className="ic"><svg viewBox="0 0 24 24"><path d="M3 13h12V6H3v7Z" /><path d="M15 9h4l2 3v1h-6" /><circle cx="6.5" cy="16.5" r="1.6" /><circle cx="17.5" cy="16.5" r="1.6" /></svg></span><span>{locale === "ar" ? "توصيل وتركيب احترافي داخل المملكة" : "Professional delivery & installation in the Kingdom"}</span></div>

            <div className="trust">
              <span className="tlabel">{locale === "ar" ? "دفع آمن موثوق" : "Secure checkout"}</span>
              <div className="pay"><span className="b">Mada</span><span className="b">Visa</span><span className="b">Apple&nbsp;Pay</span><span className="b">Mastercard</span></div>
            </div>
          </div>
        </section>
      </main>

      <section className="section specs">
        <div className="wrap">
          <div className="spec-grid reveal">
            {[
              { ar: "قماش مخملي فاخر", en: "Premium velvet", path: "M4 7c4-3 12-3 16 0M4 7v10c4 3 12 3 16 0V7M4 12c4 3 12 3 16 0" },
              { ar: "هيكل خشب طبيعي", en: "Natural wood frame", path: "M4 9h16M4 9 6 4h12l2 5M4 9v11h16V9M9 13v4M15 13v4" },
              { ar: "ضمان سنتين", en: "2-year warranty", path: "M12 3 4 6v6c0 4 3.5 7.5 8 9 4.5-1.5 8-5 8-9V6l-8-3Z M9 12l2 2 4-4" },
              { ar: "تركيب مجاني", en: "Free installation", path: "M12 2v6m0 0 3-3m-3 3L9 5M5 13h14l-1.5 8h-11L5 13Z" },
              { ar: "مناسب لغرف المعيشة", en: "Ideal for living rooms", path: "M3 10h18M5 10V7a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v3M4 10v8M20 10v8M4 16h16" },
              { ar: "صُنع بجودة عالية", en: "Crafted to last", path: "m12 2 2.4 4.9 5.4.8-3.9 3.8.9 5.4-4.8-2.5-4.8 2.5.9-5.4L4.2 7.7l5.4-.8L12 2Z" },
            ].map((item) => (
              <div className="spec" key={item.en}>
                <div className="si"><svg viewBox="0 0 24 24"><path d={item.path} /></svg></div>
                <div className="st">{item[locale]}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="wrap">
          <div className="story-grid">
            <div className="story-visual reveal"><img src="https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=1100&q=80" alt={locale === "ar" ? "أريكة ميلانو في غرفة معيشة فاخرة" : "Milano Sofa in a refined living room"} /></div>
            <div className="story-text reveal">
              <span className="eyebrow">{locale === "ar" ? "قصة القطعة" : "The story"}</span>
              <h2 className="h-display">{locale === "ar" ? "فخامة مصممة لحضور يومي" : "Luxury designed for everyday presence"}</h2>
              <p>{locale === "ar" ? "صُممت أريكة ميلانو لتكون قلب غرفة المعيشة؛ خطوطها الانسيابية ووسائدها العميقة تمنحك راحةً تدعو للاسترخاء، بينما يضفي القماش المخملي لمسةً دافئة تعكس الذوق الرفيع." : "Milano was designed to be the heart of the living room — flowing lines and deep cushions invite you to unwind, while soft velvet adds a warm touch that reflects refined taste."}</p>
              <blockquote className="story-pull">{locale === "ar" ? "«ليست مجرد أريكة، بل دعوةٌ للجلوس والتأمل والاجتماع.»" : "“Not just a sofa — an invitation to sit, reflect, and gather.”"}</blockquote>
              <p>{locale === "ar" ? "يرتكز الهيكل على خشبٍ طبيعي متين يضمن ثباتاً يدوم لأجيال، وتأتي القاعدة الإسفنجية عالية الكثافة لتحافظ على شكلها وراحتها مع مرور السنين. كل تفصيلة فيها مدروسة لتجمع بين الجمال والمتانة." : "The frame is built on solid natural wood for stability that lasts for generations, while high-density foam keeps its shape and comfort over the years. Every detail balances beauty with durability."}</p>
            </div>
          </div>
        </div>
      </section>

      <section className="section dims">
        <div className="wrap">
          <div className="dims-grid">
            <div className="reveal">
              <span className="eyebrow">{locale === "ar" ? "المقاسات" : "Dimensions"}</span>
              <h2 className="h-display dims-title">{locale === "ar" ? "مقاساتٌ تناسب مساحتك" : "Measurements that fit your space"}</h2>
              <div className="dims-list">
                {[
                  [locale === "ar" ? "العرض" : "Width", "240", locale === "ar" ? "سم" : "cm"],
                  [locale === "ar" ? "العمق" : "Depth", "95", locale === "ar" ? "سم" : "cm"],
                  [locale === "ar" ? "الارتفاع" : "Height", "82", locale === "ar" ? "سم" : "cm"],
                  [locale === "ar" ? "ارتفاع المقعد" : "Seat height", "44", locale === "ar" ? "سم" : "cm"],
                  [locale === "ar" ? "عدد المقاعد" : "Seats", "3", ""],
                ].map(([label, value, unit]) => (
                  <div className="dim" key={label}><span className="k">{label}</span><span className="v">{value} {unit ? <small>{unit}</small> : null}</span></div>
                ))}
              </div>
            </div>
            <div className="diagram reveal">
              <svg className="sofa-svg" viewBox="0 0 420 300" role="img" aria-label={locale === "ar" ? "مخطط أبعاد الأريكة" : "Sofa dimension diagram"}>
                <line className="dimline" x1="60" y1="40" x2="360" y2="40" />
                <line className="tick" x1="60" y1="32" x2="60" y2="48" />
                <line className="tick" x1="360" y1="32" x2="360" y2="48" />
                <text x="210" y="30" textAnchor="middle">240 {locale === "ar" ? "سم" : "cm"}</text>
                <rect className="body" x="60" y="120" width="300" height="70" rx="10" />
                <rect className="body" x="60" y="80" width="34" height="120" rx="10" />
                <rect className="body" x="326" y="80" width="34" height="120" rx="10" />
                <rect className="cushion" x="100" y="98" width="74" height="34" rx="6" />
                <rect className="cushion" x="184" y="98" width="74" height="34" rx="6" />
                <rect className="cushion" x="268" y="98" width="50" height="34" rx="6" />
                <rect className="cushion" x="100" y="140" width="218" height="36" rx="7" />
                <rect className="leg" x="80" y="190" width="10" height="20" />
                <rect className="leg" x="330" y="190" width="10" height="20" />
                <line className="dimline" x1="384" y1="80" x2="384" y2="210" />
                <line className="tick" x1="376" y1="80" x2="392" y2="80" />
                <line className="tick" x1="376" y1="210" x2="392" y2="210" />
                <text x="398" y="148" textAnchor="middle" transform="rotate(90 398 148)">82 {locale === "ar" ? "سم" : "cm"}</text>
                <line className="dimline" x1="40" y1="176" x2="40" y2="210" />
                <line className="tick" x1="32" y1="176" x2="48" y2="176" />
                <line className="tick" x1="32" y1="210" x2="48" y2="210" />
                <text x="26" y="196" textAnchor="middle" transform="rotate(-90 26 196)">44</text>
                <line className="dimline" x1="60" y1="252" x2="360" y2="252" opacity=".5" />
                <text x="210" y="272" textAnchor="middle">{locale === "ar" ? "العمق: 95 سم" : "Depth: 95 cm"}</text>
              </svg>
              <p className="diagram-note">{locale === "ar" ? "رسم توضيحي تقريبي للأبعاد" : "Approximate dimensional illustration"}</p>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="wrap">
          <div className="section-center reveal">
            <span className="eyebrow centered">{locale === "ar" ? "التفاصيل الكاملة" : "Full details"}</span>
            <h2 className="h-display compact-title">{locale === "ar" ? "كل ما تودّ معرفته" : "Everything you'd want to know"}</h2>
          </div>
          <div className="acc reveal" id="acc">
            {[
              { title: { ar: "الخامات", en: "Materials" }, body: { ar: "قماش مخملي فاخر مقاوم للبهتان، منسوج بكثافة عالية لملمسٍ ناعم ومتانة تدوم. الهيكل من خشب طبيعي متين، والحشوة إسفنج عالي الكثافة يحافظ على شكله.", en: "Premium fade-resistant velvet, densely woven for a soft feel and lasting durability. A solid natural-wood frame with high-density foam that holds its shape." } },
              { title: { ar: "العناية والتنظيف", en: "Care & cleaning" }, body: { ar: "يُنظّف بفرشاة ناعمة بانتظام للحفاظ على ملمس المخمل. عند الانسكاب، جفّف فوراً بقطعة قماش نظيفة دون فرك. تجنّب أشعة الشمس المباشرة المطوّلة، ويُفضّل التنظيف الجاف المتخصص عند الحاجة.", en: "Brush regularly with a soft brush to keep the velvet pile. Blot spills immediately with a clean cloth without rubbing. Avoid prolonged direct sunlight; professional dry cleaning is recommended when needed." } },
              { title: { ar: "التوصيل والتركيب", en: "Delivery & installation" }, body: { ar: "توصيل احترافي داخل المملكة خلال 5 إلى 10 أيام عمل، مع تركيب مجاني بواسطة فريقنا المتخصص في الموعد الذي يناسبك. نتولّى إزالة مواد التغليف بعد التركيب.", en: "Professional delivery across the Kingdom within 5–10 business days, with free installation by our specialised team at a time that suits you. We remove all packaging after installation." } },
              { title: { ar: "الضمان والإرجاع", en: "Warranty & returns" }, body: { ar: "ضمان لمدة سنتين يغطي عيوب التصنيع في الهيكل والخياطة. يمكنك الإرجاع أو الاستبدال خلال 14 يوماً من الاستلام شريطة أن تكون القطعة بحالتها الأصلية.", en: "A two-year warranty covering manufacturing defects in the frame and stitching. Returns or exchanges within 14 days of delivery, provided the piece is in its original condition." } },
            ].map((item, index) => (
              <div className={`acc-item${openAcc === index ? " open" : ""}`} key={item.title.en}>
                <button className="acc-head" onClick={() => setOpenAcc(openAcc === index ? -1 : index)}><span className="t">{item.title[locale]}</span><span className="acc-ic" /></button>
                <div className="acc-body"><div className="acc-body-inner"><p>{item.body[locale]}</p></div></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section room-insp">
        <div className="wrap">
          <div className="sec-head reveal">
            <div>
              <span className="eyebrow">{locale === "ar" ? "جلسة منسّقة" : "Styled set"}</span>
              <h2 className="h-display">{locale === "ar" ? "أكمل المشهد حول ميلانو" : "Complete the scene around Milano"}</h2>
            </div>
          </div>
          <div className="room-grid">
            <div className="room-scene reveal">
              <img src="https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1200&q=80" alt={locale === "ar" ? "غرفة معيشة منسّقة من رولك" : "Styled living room by Rollc"} />
              <span className="tag t1"><span className="pin" /> <span>{locale === "ar" ? "أريكة ميلانو" : "Milano Sofa"}</span></span>
              <span className="tag t2"><span className="pin" /> <span>{locale === "ar" ? "طاولة جانبية" : "Side table"}</span></span>
            </div>
            <div className="room-suggest reveal">
              <h3 className="h-display">{locale === "ar" ? "قطعٌ تكمّل الجلسة" : "Pieces that complete it"}</h3>
              <p>{locale === "ar" ? "اخترناها بعناية لتنسجم مع أريكة ميلانو." : "Hand-picked to pair beautifully with Milano."}</p>
              {[
                { ar: "طاولة جانبية مناسبة", en: "Matching side table", subAr: "خشب ورخام", subEn: "Wood & marble", price: "1,150", img: "https://images.unsplash.com/photo-1532372320572-cda25653a26d?auto=format&fit=crop&w=200&q=80" },
                { ar: "سجادة دافئة", en: "Warm rug", subAr: "صوف بلمسة ترابية", subEn: "Wool, earthy tone", price: "980", img: "https://images.unsplash.com/photo-1600166898405-da9535204843?auto=format&fit=crop&w=200&q=80" },
                { ar: "مصباح أرضي", en: "Floor lamp", subAr: "إضاءة دافئة", subEn: "Warm light", price: "890", img: "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&w=200&q=80" },
                { ar: "وسائد زخرفية", en: "Decorative cushions", subAr: "مخمل بألوان منسّقة", subEn: "Coordinated velvet", price: "240", img: "https://images.unsplash.com/photo-1584100936595-c0654b55a2e6?auto=format&fit=crop&w=200&q=80" },
              ].map((item) => (
                <button className="sug" key={item.en} onClick={() => addToCart(locale === "ar" ? `تمت إضافة ${item.ar} إلى السلة` : `${item.en} added to cart`)}>
                  <div className="si"><img src={item.img} alt="" /></div>
                  <div className="sx"><b>{locale === "ar" ? item.ar : item.en}</b><span>{locale === "ar" ? item.subAr : item.subEn}</span></div>
                  <span className="sp">{item.price} {locale === "ar" ? "ر.س" : "SAR"}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="wrap">
          <div className="rev-head reveal">
            <div>
              <span className="eyebrow">{locale === "ar" ? "آراء العملاء" : "Customer reviews"}</span>
              <h2 className="h-display compact-title">{locale === "ar" ? "تجاربٌ تروي الجودة" : "Experiences that speak quality"}</h2>
            </div>
            <div className="rev-score"><span className="big">4.9</span><div className="meta"><StarRating id="starsBig" /><span>{locale === "ar" ? "من 128 تقييماً موثّقاً" : "from 128 verified reviews"}</span></div></div>
          </div>
          <div className="rev-grid">
            {(locale === "ar"
              ? [
                ["ن", "نورة العتيبي", "«جودة الأريكة فاقت توقعاتي، القماش ناعم جداً والجلسة مريحة. التركيب كان احترافياً وفي الوقت المحدد.»"],
                ["خ", "خالد الدوسري", "«غيّرت شكل مجلسنا بالكامل، اللون الرملي راقٍ ويناسب أي ديكور. أنصح بها بشدة لمن يبحث عن الفخامة.»"],
                ["ر", "ريم الشهري", "«خدمة العملاء ممتازة، وساعدوني في اختيار المقاس المناسب لمساحتي. الأريكة متينة وتبدو أغلى من سعرها.»"],
              ]
              : [
                ["N", "Noura Al-Otaibi", "“The quality exceeded my expectations — the fabric is so soft and the seat is comfortable. Installation was professional and on time.”"],
                ["K", "Khaled Al-Dosari", "“It completely transformed our living room. The sand colour is elegant and suits any decor. Highly recommended for anyone seeking luxury.”"],
                ["R", "Reem Al-Shehri", "“Excellent customer service — they helped me pick the right size for my space. The sofa is sturdy and looks more expensive than its price.”"],
              ]).map(([initial, name, quote]) => (
              <article className="rev-card reveal" key={name}>
                <StarRating />
                <p className="q">{quote}</p>
                <div className="who"><span className="av">{initial}</span><div><b>{name}</b><span className="rev-verified">✓ <span>{locale === "ar" ? "عملية شراء موثّقة" : "Verified purchase"}</span></span></div></div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <ProductGrid locale={locale} id="related" className="related" eyebrow={{ ar: "قد يعجبك أيضاً", en: "You may also like" }} title={{ ar: "قطعٌ تنسجم مع ميلانو", en: "Pieces that pair with Milano" }} link={{ ar: "عرض الكل", en: "View all" }} items={related} onAdd={addToCart} />
      <ProductGrid locale={locale} id="similarSofas" className="similar-sofas" eyebrow={{ ar: "أرائك أخرى من رولك", en: "Similar Sofas" }} title={{ ar: "اكتشف المزيد من الأرائك الفاخرة", en: "Discover more luxury sofas" }} link={{ ar: "كل الأرائك", en: "All sofas" }} items={sofas} onAdd={addToCart} />

      <section className="section branches" id="branches">
        <div className="wrap br-inner">
          <div className="br-top reveal">
            <span className="eyebrow">{locale === "ar" ? "جرّبها بنفسك" : "Try it yourself"}</span>
            <h2 className="h-display">{locale === "ar" ? "جرّب أريكة ميلانو في أقرب معرض" : "Try the Milano Sofa at your nearest showroom"}</h2>
            <p>{locale === "ar" ? "اجلس، والمس الخامة، واختر لونك مع مستشاري التصميم لدينا." : "Sit, feel the fabric, and choose your colour with our design consultants."}</p>
          </div>
          <div className="br-grid reveal">
            {[
              ["الرياض", "Riyadh", "طريق الملك فهد، حي العليا", "King Fahd Rd, Al Olaya"],
              ["جدة", "Jeddah", "طريق الأمير سلطان، الزهراء", "Prince Sultan Rd, Al Zahraa"],
              ["الدمام", "Dammam", "طريق الملك سعود، الشاطئ", "King Saud Rd, Al Shati"],
              ["الخبر", "Khobar", "كورنيش الخبر، العقربية", "Khobar Corniche, Al Aqrabiyah"],
            ].map(([cityAr, cityEn, addrAr, addrEn]) => (
              <article className="br-card" key={cityEn}>
                <h3 className="br-city"><span className="pin"><PinIcon /></span><span>{locale === "ar" ? cityAr : cityEn}</span></h3>
                <p className="br-addr">{locale === "ar" ? addrAr : addrEn}</p>
                <p className="br-hours">10:00 — 23:00</p>
              </article>
            ))}
          </div>
          <div className="br-cta reveal"><button className="btn-gold" onClick={() => addToast(locale === "ar" ? "سنؤكد موعد زيارتك قريباً ✦" : "We'll confirm your visit soon ✦")}><span>{locale === "ar" ? "احجز موعد زيارة" : "Book a visit"}</span><span className="arrow">→</span></button></div>
        </div>
      </section>

      <footer className="footer">
        <div className="wrap">
          <div className="foot-top">
            <div className="foot-brand">
              <span className="mark">Roll<b>c</b></span>
              <div className="ar">رولـك</div>
              <p className="foot-statement">{locale === "ar" ? "رولك — حيث يلتقي التصميم بالدفء. نصنع مساحاتٍ تُحاكي ذوقك وتروي حكايتك." : "Rollc — where design meets warmth. We craft spaces that echo your taste and tell your story."}</p>
              <div className="socials"><a href="#" aria-label="Instagram">IG</a><a href="#" aria-label="X">X</a><a href="#" aria-label="Pinterest">PIN</a><a href="#" aria-label="TikTok">TT</a></div>
            </div>
            <FooterColumn title={locale === "ar" ? "تسوّق" : "Shop"} links={locale === "ar" ? ["غرف المعيشة", "غرف النوم", "طاولات الطعام", "الديكور", "العروض"] : ["Living Rooms", "Bedrooms", "Dining Tables", "Decor", "Offers"]} />
            <FooterColumn title={locale === "ar" ? "الشركة" : "Company"} links={locale === "ar" ? ["من نحن", "الفروع", "التوصيل والتركيب", "سياسة الإرجاع", "تواصل معنا"] : ["About us", "Showrooms", "Delivery & Install", "Returns", "Contact"]} />
            <div className="foot-col news">
              <h4>{locale === "ar" ? "انضم إلى رولك" : "Join Rollc"}</h4>
              <p>{locale === "ar" ? "اشترك لتصلك المجموعات الجديدة والعروض الحصرية قبل الجميع." : "Subscribe for new collections and exclusive offers first."}</p>
              <div className="news-form"><input type="email" value={newsletter} onChange={(event) => setNewsletter(event.target.value)} placeholder={locale === "ar" ? "بريدك الإلكتروني" : "Your email"} aria-label={locale === "ar" ? "البريد الإلكتروني" : "Email"} /><button onClick={() => { if (/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(newsletter.trim())) { setNewsletterMsg(locale === "ar" ? "تم الاشتراك بنجاح ✦ مرحباً بك في رولك" : "Subscribed ✦ Welcome to Rollc"); setNewsletter(""); } else { setNewsletterMsg(locale === "ar" ? "فضلاً أدخل بريداً إلكترونياً صحيحاً" : "Please enter a valid email"); } }}>{locale === "ar" ? "اشترك" : "Subscribe"}</button></div>
              <div className="news-ok">{newsletterMsg}</div>
            </div>
          </div>
          <div className="foot-bottom"><span>© 2026 Rollc رولك. <span>{locale === "ar" ? "جميع الحقوق محفوظة." : "All rights reserved."}</span></span><span>{locale === "ar" ? "طرق الدفع: Mada · Visa · Apple Pay · Mastercard" : "We accept: Mada · Visa · Apple Pay · Mastercard"}</span></div>
        </div>
      </footer>

      <div className={`search-panel${searchOpen ? " open" : ""}`} id="searchPanel">
        <div className="sp-row"><SearchIcon /><input type="text" placeholder={locale === "ar" ? "ابحث عن أريكة، طاولة، سرير…" : "Search sofas, tables, beds…"} aria-label={locale === "ar" ? "بحث" : "Search"} /><button className="sp-close" onClick={() => setSearchOpen(false)} aria-label={locale === "ar" ? "إغلاق" : "Close"}>✕</button></div>
      </div>
      <div className={`overlay${searchOpen ? " open" : ""}`} onClick={() => setSearchOpen(false)} />

      <div className={`sticky-bar${stickyBar ? " show" : ""}`} id="stickyBar">
        <div className="sb-info"><div className="sb-name">{locale === "ar" ? "أريكة ميلانو" : "Milano Sofa"}</div><div className="sb-price">4,250 {locale === "ar" ? "ر.س" : "SAR"}</div></div>
        <button className="sb-btn" onClick={() => addToCart()}><BagIcon /><span>{locale === "ar" ? "أضف إلى السلة" : "Add to cart"}</span></button>
      </div>

      <div className={`toast${toast ? " show" : ""}`} id="toast"><span className="tdot"><CheckIcon /></span><span id="toastMsg">{toast}</span></div>
    </div>
  );
}

function ProductGrid({ locale, id, className, eyebrow, title, link, items, onAdd }: { locale: Locale; id: string; className: string; eyebrow: L10n; title: L10n; link: L10n; items: ProductMini[]; onAdd: (message?: string) => void }) {
  return (
    <section className={`section ${className}`} id={id === "related" ? "related" : undefined}>
      <div className="wrap">
        <div className="sec-head reveal">
          <div>
            <span className="eyebrow">{eyebrow[locale]}</span>
            <h2 className="h-display">{title[locale]}</h2>
          </div>
          <a href="#" className="sec-link"><span>{link[locale]}</span><span>→</span></a>
        </div>
        <div className="prod-grid reveal" id={id}>
          {items.map((item) => (
            <article className="card" key={item.name.en}>
              <div className="card-media">
                {item.tag?.[locale] ? <span className="card-tag">{item.tag[locale]}</span> : null}
                <img src={item.img} alt={item.name[locale]} loading="lazy" />
                <button className="card-add" onClick={() => onAdd(locale === "ar" ? `تمت إضافة ${item.name.ar} إلى السلة` : `${item.name.en} added to cart`)}>{locale === "ar" ? "إضافة سريعة" : "Quick add"}</button>
              </div>
              <div className="card-body"><span className="card-cat">{item.cat ? item.cat[locale] : (locale === "ar" ? "أرائك" : "Sofas")}</span><h3 className="card-name">{item.name[locale]}</h3><div className="card-foot"><span className="card-price"><b>{item.price}</b> <span className="cur">{locale === "ar" ? "ر.س" : "SAR"}</span></span></div></div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function FooterColumn({ title, links }: { title: string; links: string[] }) {
  return (
    <div className="foot-col">
      <h4>{title}</h4>
      {links.map((link) => <a href="#" key={link}>{link}</a>)}
    </div>
  );
}
