export { default } from "./real/page";
