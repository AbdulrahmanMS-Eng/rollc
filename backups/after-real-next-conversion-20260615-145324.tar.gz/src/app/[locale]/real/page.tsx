import { notFound } from "next/navigation";
import { TopBar } from "@/components/rollc/layout/TopBar";
import { Header } from "@/components/rollc/layout/Header";
import { Footer } from "@/components/rollc/layout/Footer";
import { Hero } from "@/components/rollc/sections/Hero";
import { Categories } from "@/components/rollc/sections/Categories";
import { Signature } from "@/components/rollc/sections/Signature";
import { Products } from "@/components/rollc/sections/Products";
import { Showroom } from "@/components/rollc/sections/Showroom";
import { Collections } from "@/components/rollc/sections/Collections";
import { Branches } from "@/components/rollc/sections/Branches";
import { RollcProvider } from "@/components/rollc/ui/RollcStore";
import { SearchPanel } from "@/components/rollc/ui/SearchPanel";
import { QuickViewModal } from "@/components/rollc/ui/QuickViewModal";
import { Toast } from "@/components/rollc/ui/Toast";
import type { Locale } from "@/data/rollc/content";

export default async function RealRollcPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;

  if (locale !== "ar" && locale !== "en") notFound();

  const typedLocale = locale as Locale;

  return (
    <RollcProvider locale={typedLocale}>
      <main className={typedLocale === "en" ? "rollc-real-page lang-en" : "rollc-real-page"} dir={typedLocale === "ar" ? "rtl" : "ltr"}>
        <TopBar locale={typedLocale} />
        <Header locale={typedLocale} />
        <Hero locale={typedLocale} />
        <Categories locale={typedLocale} />
        <Signature locale={typedLocale} />
        <Products locale={typedLocale} />
        <Showroom locale={typedLocale} />
        <Collections locale={typedLocale} />
        <Branches locale={typedLocale} />
        <Footer locale={typedLocale} />
        <SearchPanel />
        <QuickViewModal />
        <Toast />
      </main>
    </RollcProvider>
  );
}
