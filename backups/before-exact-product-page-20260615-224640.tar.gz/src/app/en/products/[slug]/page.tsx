import { notFound } from "next/navigation";
import { RollcProductPage } from "@/components/rollc/product/RollcProductPage";
import { products } from "@/data/rollc/content";

export function generateStaticParams() {
  return products.map((product) => ({ slug: product.id }));
}

export default async function EnglishProductRoute({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = products.find((item) => item.id === slug);

  if (!product) notFound();

  return <RollcProductPage locale="en" product={product} />;
}
