import { notFound } from "next/navigation";
import { ExactProductPage } from "@/components/rollc/product/ExactProductPage";

export function generateStaticParams() {
  return [{ slug: "milano-sofa" }];
}

export default async function ArabicProductRoute({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  if (slug !== "milano-sofa") notFound();
  return <ExactProductPage initialLocale="ar" />;
}
