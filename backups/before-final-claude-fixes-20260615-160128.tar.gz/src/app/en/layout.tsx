import type { Metadata } from "next";
import "../globals.css";

export const metadata: Metadata = {
  title: "Rollc | Luxury Furniture",
  description: "Rollc — a luxury furniture experience blending architectural design, warm Gulf elegance, and modern ecommerce.",
};

export default function EnglishRootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" dir="ltr">
      <body>{children}</body>
    </html>
  );
}
