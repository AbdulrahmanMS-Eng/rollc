import "./globals.css";
import type { ReactNode } from "react";

// The <html>/<body> tags live in app/[locale]/layout.tsx so that lang/dir
// can depend on the active locale. This root layout only forwards children.
export default function RootLayout({ children }: { children: ReactNode }) {
  return children;
}
