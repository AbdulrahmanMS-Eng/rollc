import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { El_Messiri, Tajawal, Cormorant_Garamond, Jost } from "next/font/google";
import { locales, isLocale, dir, type Locale } from "@/lib/i18n";
import { getDictionary } from "@/dictionaries/types";
import { StoreProvider } from "@/components/ui/StoreProvider";
import Header from "@/components/layout/Header";
import TopBar from "@/components/layout/TopBar";
import Footer from "@/components/layout/Footer";
import SearchPanel from "@/components/ui/SearchPanel";
import QuickViewModal from "@/components/ui/QuickViewModal";
import Toast from "@/components/ui/Toast";

const elMessiri = El_Messiri({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-el-messiri",
  display: "swap",
});
const tajawal = Tajawal({
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "700"],
  variable: "--font-tajawal",
  display: "swap",
});
const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  style: ["normal", "italic"],
  variable: "--font-cormorant",
  display: "swap",
});
const jost = Jost({
  subsets: ["latin"],
  weight: ["300", "400", "500"],
  variable: "--font-jost",
  display: "swap",
});

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const isAr = locale === "ar";
  return {
    title: isAr ? "رولك Rollc — أثاث فاخر يصنع حضور المكان" : "Rollc — Fine furniture that commands the room",
    description: isAr
      ? "قطعٌ مختارة بعناية وغرفٌ منسّقة، مع توصيل وتركيب احترافي في جميع أنحاء المملكة."
      : "Carefully curated furniture and styled rooms, with professional delivery and installation across the Kingdom.",
  };
}

export default async function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const typedLocale = locale as Locale;
  const dict = await getDictionary(typedLocale);

  const fontVars = `${elMessiri.variable} ${tajawal.variable} ${cormorant.variable} ${jost.variable}`;

  return (
    <html lang={typedLocale} dir={dir(typedLocale)} className={fontVars}>
      <body className={typedLocale === "en" ? "lang-en" : ""}>
        <StoreProvider>
          <TopBar dict={dict} />
          <Header locale={typedLocale} dict={dict} />
          {children}
          <Footer dict={dict} />
          <SearchPanel dict={dict} />
          <QuickViewModal locale={typedLocale} dict={dict} />
          <Toast />
        </StoreProvider>
      </body>
    </html>
  );
}
