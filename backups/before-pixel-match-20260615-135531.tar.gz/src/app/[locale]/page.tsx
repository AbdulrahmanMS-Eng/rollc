import { isLocale, type Locale } from "@/lib/i18n";
import { notFound } from "next/navigation";
import { getDictionary } from "@/dictionaries/types";
import Hero from "@/components/sections/Hero";
import Categories from "@/components/sections/Categories";
import Signature from "@/components/sections/Signature";
import Products from "@/components/sections/Products";
import Showroom from "@/components/sections/Showroom";
import Collections from "@/components/sections/Collections";
import Branches from "@/components/sections/Branches";

export default async function HomePage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const typedLocale = locale as Locale;
  const dict = await getDictionary(typedLocale);

  return (
    <main>
      <Hero locale={typedLocale} dict={dict} />
      <Categories locale={typedLocale} dict={dict} />
      <Signature dict={dict} />
      <Products locale={typedLocale} dict={dict} />
      <Showroom dict={dict} />
      <Collections locale={typedLocale} dict={dict} />
      <Branches locale={typedLocale} dict={dict} />
    </main>
  );
}
